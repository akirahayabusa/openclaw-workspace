# 洛神平台架构设计

## 1. 项目目标

基于 AgentScope-Java 框架，构建一个企业级多智能体协作平台，支持：

- **动态配置管理**：Agent、Skill、MCP、Session、Memory 的运行时管理
- **多级智能体协作**：Leader → Core → Sub 三级架构
- **生产级部署**：支持集群部署、监控、高可用

## 2. 架构设计

### 2.1 整体架构

```
┌──────────────────────────────────────────────────────┐
│                    前端 (Vue 3)                       │
│              luoshen-web (Element Plus)              │
└──────────────────────────────────────────────────────┘
                         │ HTTP/SSE
                         ▼
┌──────────────────────────────────────────────────────┐
│                管理后台 (Spring Boot)                 │
│                  luoshen-admin:9090                  │
│  - 配置 CRUD (Agent/Skill/MCP/Session/Memory)       │
│  - 运行时管理（启动/停止/重启 Agent）                  │
│  - 实时日志查看 (WebSocket)                          │
└──────────────────────────────────────────────────────┘
                         │
         ┌───────────────┼───────────────┐
         ▼               ▼               ▼
┌─────────────┐  ┌─────────────┐  ┌─────────────┐
│ Leader Agent│  │ Core Agent 1│  │ Core Agent N│
│   :8080     │  │   :8081     │  │   :808N     │
│ (任务分发)   │  │ (设备管理)   │  │ (人员管理)   │
└─────────────┘  └─────────────┘  └─────────────┘
                         │
         ┌───────────────┼───────────────┐
         ▼               ▼               ▼
┌─────────────┐  ┌─────────────┐  ┌─────────────┐
│ Sub Agent 1 │  │ Sub Agent 2 │  │ Sub Agent N │
│ (质量检测)   │  │ (维护保养)   │  │ (库存管理)   │
└─────────────┘  └─────────────┘  └─────────────┘
```

### 2.2 模块划分

#### luoshen-core
核心业务逻辑模块，包含：
- **Agent 工厂**：动态创建 Agent 实例
- **Skill 加载器**：从文件系统加载技能
- **MCP 管理器**：管理 MCP 客户端连接
- **Session 管理**：会话持久化和恢复
- **Memory 管理**：记忆存储和检索

依赖：`agentscope-core`

#### luoshen-admin
管理后台模块，包含：
- **REST API**：配置 CRUD 接口
- **运行时管理**：Agent 启动/停止/重启
- **实时日志**：WebSocket 推送执行日志
- **Dashboard**：系统状态概览

依赖：`luoshen-core`

#### luoshen-leader
Leader Agent 模块，包含：
- **任务分发**：将用户请求分发给 Core Agent
- **结果汇总**：汇总各 Agent 执行结果
- **决策引擎**：复杂任务的决策逻辑

依赖：`luoshen-core`

#### luoshen-web
前端管理界面，包含：
- **Agent 管理**：创建/编辑/删除 Agent
- **Skill 管理**：技能编辑和加载
- **MCP 管理**：MCP 服务器配置
- **Session 查看**：会话列表和详情
- **Memory 查看**：记忆搜索和管理

技术栈：Vue 3 + TypeScript + Element Plus + Vite

## 3. 数据模型

### 3.1 Agent 配置

```sql
CREATE TABLE agent_config (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    agent_id VARCHAR(100) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    type VARCHAR(20) NOT NULL,  -- LEADER/CORE/SUB
    parent_agent_id VARCHAR(100),
    system_prompt TEXT,
    model_name VARCHAR(100),
    tools_json TEXT,            -- JSON: 工具配置
    skills_json TEXT,           -- JSON: 技能列表
    mcp_servers_json TEXT,      -- JSON: MCP 服务器列表
    enabled BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### 3.2 Skill 配置

```sql
CREATE TABLE skill_config (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    skill_id VARCHAR(100) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    content TEXT,               -- Markdown 格式技能定义
    file_path VARCHAR(500),     -- 文件系统路径
    enabled BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### 3.3 MCP 配置

```sql
CREATE TABLE mcp_config (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    mcp_id VARCHAR(100) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    transport_type VARCHAR(20), -- STDIO/WEBSOCKET
    command VARCHAR(500),       -- STDIO 命令
    url VARCHAR(500),           -- WebSocket URL
    enabled BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## 4. API 设计

### 4.1 Agent 管理

```
POST   /api/agents              # 创建 Agent
GET    /api/agents              # 列出所有 Agent
GET    /api/agents/{agentId}    # 获取 Agent 详情
PUT    /api/agents/{agentId}    # 更新 Agent
DELETE /api/agents/{agentId}    # 删除 Agent
POST   /api/agents/{agentId}/start    # 启动 Agent
POST   /api/agents/{agentId}/stop     # 停止 Agent
POST   /api/agents/{agentId}/restart  # 重启 Agent
GET    /api/agents/tree         # 获取 Agent 树形结构
```

### 4.2 Skill 管理

```
POST   /api/skills              # 创建 Skill
GET    /api/skills              # 列出所有 Skill
GET    /api/skills/{skillId}    # 获取 Skill 详情
PUT    /api/skills/{skillId}    # 更新 Skill
DELETE /api/skills/{skillId}    # 删除 Skill
POST   /api/skills/{skillId}/load    # 加载 Skill
POST   /api/skills/{skillId}/unload  # 卸载 Skill
```

### 4.3 会话管理

```
GET    /api/sessions            # 列出所有会话
GET    /api/sessions/{sessionId} # 获取会话详情
DELETE /api/sessions/{sessionId} # 删除会话
POST   /api/sessions/{sessionId}/chat  # 发送消息
```

### 4.4 Dashboard

```
GET    /api/dashboard/stats     # 系统统计
GET    /api/dashboard/health    # 健康检查
```

## 5. 开发优先级

### Phase 1: 核心功能（1-2周）
- [x] 项目初始化
- [ ] luoshen-core 核心模块
  - [ ] Agent 工厂
  - [ ] Skill 加载器
  - [ ] MCP 管理器
- [ ] luoshen-admin REST API
- [ ] luoshen-leader 基础框架

### Phase 2: 前端界面（1周）
- [ ] luoshen-web 项目初始化
- [ ] Agent 管理页面
- [ ] Skill 管理页面
- [ ] Dashboard 页面

### Phase 3: 高级功能（1-2周）
- [ ] 实时日志查看（WebSocket）
- [ ] 子智能体协作
- [ ] 分布式部署支持
- [ ] 监控和告警

### Phase 4: 生产化（1周）
- [ ] Docker 容器化
- [ ] MySQL 支持
- [ ] 性能优化
- [ ] 部署文档

## 6. 参考资源

- [AgentScope-Java 文档](https://java.agentscope.io/zh/intro.html)
- [AgentScope-Java GitHub](https://github.com/agentscope-ai/agentscope-java)
- [hitl-chat 示例](../agentscope-java/agentscope-examples/hitl-chat)
