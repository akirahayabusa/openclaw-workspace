// src/api/agents.ts
import axios from 'axios';

const API_BASE = '/api';

export interface Agent {
  id: number;
  agentId: string;
  name: string;
  description?: string;
  type: 'LEADER' | 'CORE' | 'SUB';
  parentAgentId?: string;
  systemPrompt?: string;
  modelName?: string;
  enabled: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface AgentTree {
  leader: Agent | null;
  coreAgents: Array<{
    agent: Agent;
    subAgents: Agent[];
  }>;
}

export const agentApi = {
  // 获取所有 Agent
  async list(): Promise<Agent[]> {
    const response = await axios.get<Agent[]>(`${API_BASE}/agents`);
    return response.data;
  },

  // 获取 Agent 树
  async getTree(): Promise<AgentTree> {
    const response = await axios.get<AgentTree>(`${API_BASE}/agents/tree`);
    return response.data;
  },

  // 创建 Agent
  async create(agent: Partial<Agent>): Promise<Agent> {
    const response = await axios.post<Agent>(`${API_BASE}/agents`, agent);
    return response.data;
  },

  // 更新 Agent
  async update(agentId: string, agent: Partial<Agent>): Promise<Agent> {
    const response = await axios.put<Agent>(`${API_BASE}/agents/${agentId}`, agent);
    return response.data;
  },

  // 删除 Agent
  async delete(agentId: string): Promise<void> {
    await axios.delete(`${API_BASE}/agents/${agentId}`);
  },

  // 获取 Agent 详情
  async get(agentId: string): Promise<Agent> {
    const response = await axios.get<Agent>(`${API_BASE}/agents/${agentId}`);
    return response.data;
  },

  // 获取子 Agent
  async getChildren(agentId: string): Promise<Agent[]> {
    const response = await axios.get<Agent[]>(`${API_BASE}/agents/${agentId}/children`);
    return response.data;
  }
}
