<template>
  <div class="mcp-list">
    <div class="toolbar">
      <el-button type="primary" @click="showCreateDialog">
        <el-icon><Plus /></el-icon>
        添加 MCP 服务器
      </el-button>
    </div>

    <el-table :data="mcps" v-loading="loading" stripe>
      <el-table-column prop="mcpId" label="ID" width="200" />
      <el-table-column prop="name" label="名称" width="200" />
      <el-table-column prop="transportType" label="类型" width="100">
        <template #default="{ row }">
          <el-tag>{{ row.transportType }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="连接信息">
        <template #default="{ row }">
          <span v-if="row.command">{{ row.command }}</span>
          <span v-else-if="row.url">{{ row.url }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="enabled" label="状态" width="100">
        <template #default="{ row }">
          <el-tag :type="row.enabled ? 'success' : 'danger'">
            {{ row.enabled ? '启用' : '禁用' }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="150">
        <template #default="{ row }">
          <el-button link type="primary" @click="editMcp(row)">编辑</el-button>
          <el-button link type="danger" @click="deleteMcp(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-dialog v-model="dialogVisible" title="添加 MCP 服务器" width="600px">
      <el-form :model="form" label-width="100px">
        <el-form-item label="MCP ID">
          <el-input v-model="form.mcpId" :disabled="!!editingMcp" />
        </el-form-item>
        <el-form-item label="名称">
          <el-input v-model="form.name" />
        </el-form-item>
        <el-form-item label="传输类型">
          <el-select v-model="form.transportType" style="width: 100%">
            <el-option label="STDIO" value="STDIO" />
            <el-option label="SSE" value="SSE" />
            <el-option label="HTTP" value="HTTP" />
          </el-select>
        </el-form-item>
        <el-form-item v-if="form.transportType === 'STDIO'" label="命令">
          <el-input v-model="form.command" placeholder="例如: npx -y @modelcontextprotocol/server-filesystem" />
        </el-form-item>
        <el-form-item v-else label="URL">
          <el-input v-model="form.url" placeholder="http://localhost:3000/sse" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="saveMcp">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus } from '@element-plus/icons-vue'
import axios from 'axios'

const mcps = ref<any[]>([])
const loading = ref(false)
const dialogVisible = ref(false)
const editingMcp = ref<any>(null)
const form = ref({
  mcpId: '',
  name: '',
  transportType: 'STDIO',
  command: '',
  url: '',
  enabled: true
})

const fetchMcps = async () => {
  loading.value = true
  try {
    const res = await axios.get('/api/mcp')
    mcps.value = res.data
  } catch (error) {
    ElMessage.error('获取列表失败')
  } finally {
    loading.value = false
  }
}

const showCreateDialog = () => {
  editingMcp.value = null
  form.value = { mcpId: '', name: '', transportType: 'STDIO', command: '', url: '', enabled: true }
  dialogVisible.value = true
}

const editMcp = (mcp: any) => {
  editingMcp.value = mcp
  form.value = { ...mcp }
  dialogVisible.value = true
}

const saveMcp = async () => {
  try {
    if (editingMcp.value) {
      await axios.put(`/api/mcp/${form.value.mcpId}`, form.value)
      ElMessage.success('更新成功')
    } else {
      await axios.post('/api/mcp', form.value)
      ElMessage.success('创建成功')
    }
    dialogVisible.value = false
    fetchMcps()
  } catch (error: any) {
    ElMessage.error(error.response?.data?.error || '保存失败')
  }
}

const deleteMcp = async (mcp: any) => {
  try {
    await ElMessageBox.confirm('确定删除该 MCP 配置？', '提示', { type: 'warning' })
    await axios.delete(`/api/mcp/${mcp.mcpId}`)
    ElMessage.success('删除成功')
    fetchMcps()
  } catch (error: any) {
    if (error !== 'cancel') {
      ElMessage.error(error.response?.data?.error || '删除失败')
    }
  }
}

onMounted(fetchMcps)
</script>

<style scoped>
.mcp-list {
  padding: 20px;
}
.toolbar {
  margin-bottom: 20px;
}
</style>
