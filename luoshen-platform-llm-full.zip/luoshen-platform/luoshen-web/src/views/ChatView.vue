<template>
  <div class="chat-view">
    <div class="chat-header">
      <el-select v-model="selectedAgent" placeholder="选择智能体" style="width: 200px">
        <el-option
          v-for="agent in agents"
          :key="agent.agentId"
          :label="agent.name"
          :value="agent.agentId"
        />
      </el-select>
      <el-input
        v-model="sessionId"
        placeholder="会话 ID"
        style="width: 300px; margin-left: 20px"
      />
      <el-button type="danger" @click="clearChat" style="margin-left: 10px">清空会话</el-button>
    </div>

    <div class="chat-messages" ref="messagesContainer">
      <div
        v-for="(msg, index) in messages"
        :key="index"
        :class="['message', msg.role]"
      >
        <div class="message-header">
          <strong>{{ msg.role === 'user' ? '用户' : '助手' }}</strong>
        </div>
        <div class="message-content">{{ msg.content }}</div>
      </div>
      <div v-if="streaming" class="message assistant">
        <div class="message-header"><strong>助手</strong></div>
        <div class="message-content">{{ streamingContent }}</div>
      </div>
    </div>

    <div class="chat-input">
      <el-input
        v-model="inputMessage"
        placeholder="输入消息..."
        @keyup.enter="sendMessage"
        :disabled="!selectedAgent || streaming"
      />
      <el-button type="primary" @click="sendMessage" :loading="streaming" :disabled="!selectedAgent">
        发送
      </el-button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, nextTick, watch } from 'vue'
import { useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'
import axios from 'axios'

const route = useRoute()
const agents = ref<any[]>([])
const selectedAgent = ref('')
const sessionId = ref('session-' + Date.now())
const messages = ref<{ role: string; content: string }[]>([])
const inputMessage = ref('')
const streaming = ref(false)
const streamingContent = ref('')
const messagesContainer = ref<HTMLElement | null>(null)

const scrollToBottom = async () => {
  await nextTick()
  if (messagesContainer.value) {
    messagesContainer.value.scrollTop = messagesContainer.value.scrollHeight
  }
}

const fetchAgents = async () => {
  try {
    const res = await axios.get('/api/agents')
    agents.value = res.data.filter((a: any) => a.enabled)
    
    // 从 URL 参数选择 Agent
    if (route.query.agentId) {
      selectedAgent.value = route.query.agentId as string
    }
  } catch (error) {
    ElMessage.error('获取 Agent 列表失败')
  }
}

const sendMessage = async () => {
  if (!inputMessage.value.trim() || !selectedAgent.value) return

  const userMessage = inputMessage.value
  messages.value.push({ role: 'user', content: userMessage })
  inputMessage.value = ''
  streaming.value = true
  streamingContent.value = ''
  
  await scrollToBottom()

  try {
    // 使用流式 API
    const response = await fetch('/api/chat/stream', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        sessionId: sessionId.value,
        agentId: selectedAgent.value,
        message: userMessage
      })
    })

    const reader = response.body?.getReader()
    const decoder = new TextDecoder()

    while (reader) {
      const { done, value } = await reader.read()
      if (done) break

      const text = decoder.decode(value)
      const lines = text.split('\n').filter(line => line.startsWith('data:'))

      for (const line of lines) {
        try {
          const data = JSON.parse(line.slice(5))
          if (data.content) {
            streamingContent.value += data.content
            await scrollToBottom()
          }
          if (data.isLast) {
            messages.value.push({ role: 'assistant', content: streamingContent.value })
            streamingContent.value = ''
          }
        } catch (e) {
          // 忽略解析错误
        }
      }
    }
  } catch (error) {
    ElMessage.error('发送消息失败')
  } finally {
    streaming.value = false
  }
}

const clearChat = async () => {
  try {
    await axios.delete(`/api/chat/session/${sessionId.value}`)
    messages.value = []
    sessionId.value = 'session-' + Date.now()
    ElMessage.success('会话已清空')
  } catch (error) {
    ElMessage.error('清空失败')
  }
}

watch(messages, scrollToBottom, { deep: true })

onMounted(fetchAgents)
</script>

<style scoped>
.chat-view {
  display: flex;
  flex-direction: column;
  height: calc(100vh - 120px);
  padding: 20px;
}

.chat-header {
  display: flex;
  align-items: center;
  margin-bottom: 20px;
}

.chat-messages {
  flex: 1;
  overflow-y: auto;
  background: #fff;
  border-radius: 8px;
  padding: 20px;
  margin-bottom: 20px;
}

.message {
  margin-bottom: 16px;
  padding: 12px;
  border-radius: 8px;
}

.message.user {
  background: #e3f2fd;
  margin-left: 40px;
}

.message.assistant {
  background: #f5f5f5;
  margin-right: 40px;
}

.message-header {
  margin-bottom: 8px;
  color: #666;
}

.message-content {
  white-space: pre-wrap;
  word-break: break-word;
}

.chat-input {
  display: flex;
  gap: 10px;
}

.chat-input .el-input {
  flex: 1;
}
</style>
