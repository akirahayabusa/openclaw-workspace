<template>
  <div class="agent-list">
    <div class="toolbar">
      <el-button type="primary" @click="showCreateDialog">
        <el-icon><Plus /></el-icon>
        创建 Agent
      </el-button>
    </div>

    <el-table :data="agents" v-loading="loading" stripe>
      <el-table-column prop="agentId" label="ID" width="150" />
      <el-table-column prop="name" label="名称" width="200" />
      <el-table-column prop="type" label="类型" width="100">
        <template #default="{ row }">
          <el-tag :type="getTagType(row.type)">{{ row.type }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="modelName" label="模型" width="150" />
      <el-table-column prop="enabled" label="状态" width="100">
        <template #default="{ row }">
          <el-switch v-model="row.enabled" @change="toggleEnabled(row)" />
        </template>
      </el-table-column>
      <el-table-column label="操作" width="200">
        <template #default="{ row }">
          <el-button link type="primary" @click="editAgent(row)">编辑</el-button>
          <el-button link type="primary" @click="chatWith(row)">对话</el-button>
          <el-button link type="danger" @click="deleteAgent(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 创建/编辑对话框 -->
    <el-dialog v-model="dialogVisible" :title="editingAgent ? '编辑 Agent' : '创建 Agent'" width="600px">
      <el-form :model="form" label-width="100px">
        <el-form-item label="Agent ID">
          <el-input v-model="form.agentId" :disabled="!!editingAgent" placeholder="唯一标识" />
        </el-form-item>
        <el-form-item label="名称">
          <el-input v-model="form.name" placeholder="显示名称" />
        </el-form-item>
        <el-form-item label="类型">
          <el-select v-model="form.type" style="width: 100%">
            <el-option label="Leader" value="LEADER" />
            <el-option label="Core" value="CORE" />
            <el-option label="Sub" value="SUB" />
          </el-select>
        </el-form-item>
        <el-form-item label="父 Agent">
          <el-select v-model="form.parentAgentId" clearable style="width: 100%" placeholder="选择父 Agent">
            <el-option
              v-for="agent in parentCandidates"
              :key="agent.agentId"
              :label="agent.name"
              :value="agent.agentId"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="模型">
          <el-input v-model="form.modelName" placeholder="qwen-plus" />
        </el-form-item>
        <el-form-item label="系统提示词">
          <el-input v-model="form.systemPrompt" type="textarea" :rows="4" />
        </el-form-item>
        <el-form-item label="描述">
          <el-input v-model="form.description" type="textarea" :rows="2" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="saveAgent">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus } from '@element-plus/icons-vue'
import axios from 'axios'

const router = useRouter()
const agents = ref<any[]>([])
const loading = ref(false)
const dialogVisible = ref(false)
const editingAgent = ref<any>(null)
const form = ref({
  agentId: '',
  name: '',
  type: 'CORE',
  parentAgentId: '',
  modelName: 'qwen-plus',
  systemPrompt: '',
  description: '',
  enabled: true
})

const getTagType = (type: string) => {
  switch (type) {
    case 'LEADER': return 'danger'
    case 'CORE': return 'warning'
    case 'SUB': return 'success'
    default: return 'info'
  }
}

const parentCandidates = computed(() => {
  if (form.value.type === 'CORE') {
    return agents.value.filter(a => a.type === 'LEADER')
  } else if (form.value.type === 'SUB') {
    return agents.value.filter(a => a.type === 'CORE')
  }
  return []
})

const fetchAgents = async () => {
  loading.value = true
  try {
    const res = await axios.get('/api/agents')
    agents.value = res.data
  } catch (error) {
    ElMessage.error('获取列表失败')
  } finally {
    loading.value = false
  }
}

const showCreateDialog = () => {
  editingAgent.value = null
  form.value = {
    agentId: '',
    name: '',
    type: 'CORE',
    parentAgentId: '',
    modelName: 'qwen-plus',
    systemPrompt: '',
    description: '',
    enabled: true
  }
  dialogVisible.value = true
}

const editAgent = (agent: any) => {
  editingAgent.value = agent
  form.value = { ...agent }
  dialogVisible.value = true
}

const saveAgent = async () => {
  try {
    if (editingAgent.value) {
      await axios.put(`/api/agents/${form.value.agentId}`, form.value)
      ElMessage.success('更新成功')
    } else {
      await axios.post('/api/agents', form.value)
      ElMessage.success('创建成功')
    }
    dialogVisible.value = false
    fetchAgents()
  } catch (error: any) {
    ElMessage.error(error.response?.data?.error || '保存失败')
  }
}

const deleteAgent = async (agent: any) => {
  try {
    await ElMessageBox.confirm('确定删除该 Agent？', '提示', { type: 'warning' })
    await axios.delete(`/api/agents/${agent.agentId}`)
    ElMessage.success('删除成功')
    fetchAgents()
  } catch (error: any) {
    if (error !== 'cancel') {
      ElMessage.error(error.response?.data?.error || '删除失败')
    }
  }
}

const toggleEnabled = async (agent: any) => {
  try {
    await axios.put(`/api/agents/${agent.agentId}`, { enabled: agent.enabled })
    ElMessage.success(agent.enabled ? '已启用' : '已禁用')
  } catch (error) {
    agent.enabled = !agent.enabled
  }
}

const chatWith = (agent: any) => {
  router.push({ path: '/chat', query: { agentId: agent.agentId } })
}

onMounted(fetchAgents)
</script>

<style scoped>
.agent-list {
  padding: 20px;
}
.toolbar {
  margin-bottom: 20px;
}
</style>
