<template>
  <div class="dashboard">
    <el-row :gutter="20">
      <el-col :span="6">
        <el-card shadow="hover">
          <el-statistic title="智能体总数" :value="stats.agentCount" />
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="hover">
          <el-statistic title="技能总数" :value="stats.skillCount" />
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="hover">
          <el-statistic title="MCP 连接" :value="stats.mcpCount" />
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="hover">
          <el-statistic title="会话数" :value="stats.sessionCount" />
        </el-card>
      </el-col>
    </el-row>

    <el-card class="mt-4">
      <template #header>
        <span>Agent 架构</span>
      </template>
      <div class="agent-tree">
        <el-tree
          :data="treeData"
          :props="{ label: 'name', children: 'children' }"
          default-expand-all
        >
          <template #default="{ node, data }">
            <span class="tree-node">
              <el-tag :type="getTagType(data.type)" size="small">
                {{ data.type }}
              </el-tag>
              <span class="ml-2">{{ data.name }}</span>
            </span>
          </template>
        </el-tree>
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import axios from 'axios'

const stats = ref({
  agentCount: 0,
  skillCount: 0,
  mcpCount: 0,
  sessionCount: 0
})

const treeData = ref<any[]>([])

const getTagType = (type: string) => {
  switch (type) {
    case 'LEADER': return 'danger'
    case 'CORE': return 'warning'
    case 'SUB': return 'success'
    default: return 'info'
  }
}

onMounted(async () => {
  try {
    // 获取统计
    const agentsRes = await axios.get('/api/agents')
    stats.value.agentCount = agentsRes.data.length

    const skillsRes = await axios.get('/api/skills')
    stats.value.skillCount = skillsRes.data.length

    const mcpRes = await axios.get('/api/mcp')
    stats.value.mcpCount = mcpRes.data.length

    // 获取树形结构
    const treeRes = await axios.get('/api/agents/tree')
    if (treeRes.data.leader) {
      treeData.value = [{
        name: treeRes.data.leader.name,
        type: 'LEADER',
        children: treeRes.data.coreAgents.map((core: any) => ({
          name: core.agent.name,
          type: 'CORE',
          children: core.subAgents.map((sub: any) => ({
            name: sub.name,
            type: 'SUB'
          }))
        }))
      }]
    }
  } catch (error) {
    console.error('加载数据失败', error)
  }
})
</script>

<style scoped>
.dashboard {
  padding: 20px;
}
.mt-4 {
  margin-top: 20px;
}
.ml-2 {
  margin-left: 8px;
}
.tree-node {
  display: flex;
  align-items: center;
}
</style>
