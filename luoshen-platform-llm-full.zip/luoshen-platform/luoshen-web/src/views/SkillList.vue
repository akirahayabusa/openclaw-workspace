<template>
  <div class="skill-list">
    <div class="toolbar">
      <el-button type="primary" @click="showCreateDialog">
        <el-icon><Plus /></el-icon>
        创建技能
      </el-button>
    </div>

    <el-table :data="skills" v-loading="loading" stripe>
      <el-table-column prop="skillId" label="ID" width="200" />
      <el-table-column prop="name" label="名称" width="200" />
      <el-table-column prop="description" label="描述" show-overflow-tooltip />
      <el-table-column prop="enabled" label="状态" width="100">
        <template #default="{ row }">
          <el-tag :type="row.enabled ? 'success' : 'danger'">
            {{ row.enabled ? '启用' : '禁用' }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="150">
        <template #default="{ row }">
          <el-button link type="primary" @click="editSkill(row)">编辑</el-button>
          <el-button link type="danger" @click="deleteSkill(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-dialog v-model="dialogVisible" :title="editingSkill ? '编辑技能' : '创建技能'" width="800px">
      <el-form :model="form" label-width="100px">
        <el-form-item label="技能 ID">
          <el-input v-model="form.skillId" :disabled="!!editingSkill" />
        </el-form-item>
        <el-form-item label="名称">
          <el-input v-model="form.name" />
        </el-form-item>
        <el-form-item label="描述">
          <el-input v-model="form.description" type="textarea" :rows="2" />
        </el-form-item>
        <el-form-item label="技能内容">
          <el-input v-model="form.content" type="textarea" :rows="10" placeholder="Markdown 格式" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="saveSkill">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus } from '@element-plus/icons-vue'
import axios from 'axios'

const skills = ref<any[]>([])
const loading = ref(false)
const dialogVisible = ref(false)
const editingSkill = ref<any>(null)
const form = ref({
  skillId: '',
  name: '',
  description: '',
  content: '',
  enabled: true
})

const fetchSkills = async () => {
  loading.value = true
  try {
    const res = await axios.get('/api/skills')
    skills.value = res.data
  } catch (error) {
    ElMessage.error('获取列表失败')
  } finally {
    loading.value = false
  }
}

const showCreateDialog = () => {
  editingSkill.value = null
  form.value = { skillId: '', name: '', description: '', content: '', enabled: true }
  dialogVisible.value = true
}

const editSkill = (skill: any) => {
  editingSkill.value = skill
  form.value = { ...skill }
  dialogVisible.value = true
}

const saveSkill = async () => {
  try {
    if (editingSkill.value) {
      await axios.put(`/api/skills/${form.value.skillId}`, form.value)
      ElMessage.success('更新成功')
    } else {
      await axios.post('/api/skills', form.value)
      ElMessage.success('创建成功')
    }
    dialogVisible.value = false
    fetchSkills()
  } catch (error: any) {
    ElMessage.error(error.response?.data?.error || '保存失败')
  }
}

const deleteSkill = async (skill: any) => {
  try {
    await ElMessageBox.confirm('确定删除该技能？', '提示', { type: 'warning' })
    await axios.delete(`/api/skills/${skill.skillId}`)
    ElMessage.success('删除成功')
    fetchSkills()
  } catch (error: any) {
    if (error !== 'cancel') {
      ElMessage.error(error.response?.data?.error || '删除失败')
    }
  }
}

onMounted(fetchSkills)
</script>

<style scoped>
.skill-list {
  padding: 20px;
}
.toolbar {
  margin-bottom: 20px;
}
</style>
