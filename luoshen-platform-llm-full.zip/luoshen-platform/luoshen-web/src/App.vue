<template>
  <div class="app-container">
    <el-container>
      <!-- 侧边栏 -->
      <el-aside width="220px">
        <div class="logo">
          <h2>洛神平台</h2>
        </div>
        <el-menu :default-active="activeMenu" router>
          <el-menu-item index="/dashboard">
            <el-icon><Monitor /></el-icon>
            <span>仪表盘</span>
          </el-menu-item>
          <el-menu-item index="/agents">
            <el-icon><User /></el-icon>
            <span>智能体管理</span>
          </el-menu-item>
          <el-menu-item index="/skills">
            <el-icon><Document /></el-icon>
            <span>技能管理</span>
          </el-menu-item>
          <el-menu-item index="/mcp">
            <el-icon><Connection /></el-icon>
            <span>MCP 配置</span>
          </el-menu-item>
          <el-menu-item index="/chat">
            <el-icon><ChatDotRound /></el-icon>
            <span>对话测试</span>
          </el-menu-item>
        </el-menu>
      </el-aside>

      <!-- 主内容区 -->
      <el-container>
        <el-header>
          <h3>{{ pageTitle }}</h3>
        </el-header>
        <el-main>
          <router-view />
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import { Monitor, User, Document, Connection, ChatDotRound } from '@element-plus/icons-vue'

const route = useRoute()
const activeMenu = computed(() => route.path)

const pageTitles: Record<string, string> = {
  '/dashboard': '仪表盘',
  '/agents': '智能体管理',
  '/skills': '技能管理',
  '/mcp': 'MCP 配置',
  '/chat': '对话测试'
}

const pageTitle = computed(() => pageTitles[route.path] || '洛神平台')
</script>

<style>
.app-container {
  height: 100vh;
}

.el-aside {
  background: #304156;
  color: #fff;
}

.logo {
  height: 60px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #263445;
}

.logo h2 {
  color: #fff;
  margin: 0;
  font-size: 18px;
}

.el-menu {
  border-right: none;
}

.el-header {
  background: #fff;
  box-shadow: 0 1px 4px rgba(0, 21, 41, 0.08);
  display: flex;
  align-items: center;
}

.el-header h3 {
  margin: 0;
  font-size: 18px;
  color: #303133;
}

.el-main {
  background: #f0f2f5;
}
</style>
