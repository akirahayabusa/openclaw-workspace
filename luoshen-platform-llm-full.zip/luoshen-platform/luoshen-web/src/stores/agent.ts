import { defineStore } from 'pinia'

import { ref } from 'vue'

export const useAgentStore = defineStore('agent', () => {
  const agents = ref<Agent[]>([])
  const loading = ref(false)
  const currentAgent = ref<Agent | null>(null)
  const agentTree = ref<AgentTree | null>(null)

  const actions = {
    async fetchAgents() {
      this.loading = true
      try {
        const data = await agentApi.list()
        this.agents = data
      } catch (error) {
        console.error('Failed to fetch agents:', error)
      } finally {
        this.loading = false
      }
    },

    async fetchAgentTree() {
      try {
        const data = await agentApi.getTree()
        this.agentTree = data
      } catch (error) {
        console.error('Failed to fetch agent tree:', error)
      }
    },

    async createAgent(agent: Partial<Agent>) {
      const created = await agentApi.create(agent)
      this.agents.push(created)
      return created
    },

    async updateAgent(agentId: string, agent: Partial<Agent>) {
      await agentApi.update(agentId, agent)
      const index = this.agents.findIndex(a => a.agentId === agentId)
      if (index > -1) {
        this.agents[index] = { ...this.agents[index], ...agent }
        }
      }
    },

    async deleteAgent(agentId: string) {
      await agentApi.delete(agentId)
        this.agents = this.agents.filter(a => a.agentId !== agentId)
      }
    },

    setCurrentAgent(agent: Agent | null) {
      this.currentAgent = agent
    }
  }
})
