/*
 * Copyright 2024-2026 Luoshen Team
 */
package io.luoshen.admin.runtime;

import io.agentscope.core.skill.AgentSkill;
import io.agentscope.core.skill.repository.FileSystemSkillRepository;
import io.agentscope.core.tool.Toolkit;
import io.luoshen.admin.model.SkillConfigEntity;
import io.luoshen.admin.repository.SkillConfigRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;

/**
 * 技能运行时服务
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class SkillRuntimeService {
    
    private final SkillConfigRepository skillConfigRepository;
    
    @Value("${luoshen.skills.path:./data/skills}")
    private String skillsPath;
    
    private FileSystemSkillRepository skillRepository;
    
    @PostConstruct
    public void init() {
        try {
            Path path = Paths.get(skillsPath);
            if (!Files.exists(path)) {
                Files.createDirectories(path);
            }
            this.skillRepository = new FileSystemSkillRepository(path, false);
            log.info("SkillRuntimeService 初始化完成, 路径: {}", path);
        } catch (Exception e) {
            log.error("初始化技能仓库失败", e);
        }
    }
    
    /**
     * 加载技能到 Toolkit
     */
    public void loadSkillToToolkit(String skillId, Toolkit toolkit) {
        try {
            // 从文件系统加载
            if (skillRepository != null && skillRepository.skillExists(skillId)) {
                AgentSkill skill = skillRepository.getSkill(skillId);
                if (skill != null) {
                    log.info("技能加载成功: {}", skillId);
                    return;
                }
            }
            
            // 从数据库加载
            Optional<SkillConfigEntity> configOpt = skillConfigRepository.findBySkillId(skillId);
            if (configOpt.isPresent()) {
                SkillConfigEntity config = configOpt.get();
                if (config.getEnabled() && config.getContent() != null) {
                    // 同步到文件系统
                    syncSkillToFile(config);
                    log.info("技能从数据库加载: {}", skillId);
                }
            }
        } catch (Exception e) {
            log.error("加载技能失败: {}", skillId, e);
        }
    }
    
    /**
     * 同步技能到文件系统
     */
    public void syncSkillToFile(SkillConfigEntity config) {
        try {
            if (config.getContent() != null && !config.getContent().isBlank()) {
                Path skillFile = Paths.get(skillsPath, config.getName() + ".md");
                Files.writeString(skillFile, config.getContent());
                // 重新加载仓库
                this.skillRepository = new FileSystemSkillRepository(Paths.get(skillsPath), false);
                log.info("技能已同步: {}", skillFile);
            }
        } catch (Exception e) {
            log.error("同步技能失败: {}", config.getSkillId(), e);
        }
    }
}
