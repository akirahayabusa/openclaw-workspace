/*
 * Copyright 2024-2026 Luoshen Team
 */
package io.luoshen.admin.controller;

import io.luoshen.admin.model.AgentConfigEntity;
import io.luoshen.admin.service.AgentConfigService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Agent 管理接口
 */
@RestController
@RequestMapping("/api/agents")
@RequiredArgsConstructor
public class AgentController {
    
    private final AgentConfigService agentConfigService;
    
    /**
     * 创建 Agent
     */
    @PostMapping
    public ResponseEntity<AgentConfigEntity> create(@RequestBody AgentConfigEntity config) {
        return ResponseEntity.ok(agentConfigService.create(config));
    }
    
    /**
     * 获取所有 Agent
     */
    @GetMapping
    public ResponseEntity<List<AgentConfigEntity>> list() {
        return ResponseEntity.ok(agentConfigService.listAll());
    }
    
    /**
     * 获取 Agent 详情
     */
    @GetMapping("/{agentId}")
    public ResponseEntity<AgentConfigEntity> get(@PathVariable String agentId) {
        return ResponseEntity.ok(agentConfigService.get(agentId));
    }
    
    /**
     * 更新 Agent
     */
    @PutMapping("/{agentId}")
    public ResponseEntity<AgentConfigEntity> update(
            @PathVariable String agentId,
            @RequestBody AgentConfigEntity config) {
        return ResponseEntity.ok(agentConfigService.update(agentId, config));
    }
    
    /**
     * 删除 Agent
     */
    @DeleteMapping("/{agentId}")
    public ResponseEntity<Void> delete(@PathVariable String agentId) {
        agentConfigService.delete(agentId);
        return ResponseEntity.noContent().build();
    }
    
    /**
     * 获取 Agent 树形结构
     */
    @GetMapping("/tree")
    public ResponseEntity<Map<String, Object>> getTree() {
        return ResponseEntity.ok(agentConfigService.getAgentTree());
    }
    
    /**
     * 按类型获取 Agent
     */
    @GetMapping("/type/{type}")
    public ResponseEntity<List<AgentConfigEntity>> getByType(@PathVariable String type) {
        return ResponseEntity.ok(agentConfigService.getByType(type));
    }
    
    /**
     * 获取子 Agent
     */
    @GetMapping("/{agentId}/children")
    public ResponseEntity<List<AgentConfigEntity>> getChildren(@PathVariable String agentId) {
        return ResponseEntity.ok(agentConfigService.getChildren(agentId));
    }
}
