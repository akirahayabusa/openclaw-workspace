/*
 * Copyright 2024-2026 Luoshen Team
 */
package io.luoshen.admin.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

/**
 * MCP 配置实体
 */
@Data
@Entity
@Table(name = "mcp_config")
public class McpConfigEntity {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(unique = true, nullable = false, length = 100)
    private String mcpId;
    
    @Column(nullable = false, length = 200)
    private String name;
    
    @Column(length = 20)
    private String transportType; // STDIO, SSE, HTTP
    
    @Column(length = 500)
    private String command; // STDIO 命令
    
    @Column(length = 500)
    private String url; // SSE/HTTP URL
    
    @Column(columnDefinition = "TEXT")
    private String argsJson; // 命令参数
    
    @Column(columnDefinition = "TEXT")
    private String headersJson; // HTTP 头
    
    @Column(nullable = false)
    private Boolean enabled = true;
    
    @Column(updatable = false)
    private LocalDateTime createdAt;
    
    private LocalDateTime updatedAt;
    
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = createdAt;
    }
    
    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
