/*
 * Copyright 2024-2026 Luoshen Team
 */
package io.luoshen.admin.repository;

import io.luoshen.admin.model.McpConfigEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface McpConfigRepository extends JpaRepository<McpConfigEntity, Long> {
    
    Optional<McpConfigEntity> findByMcpId(String mcpId);
    
    List<McpConfigEntity> findByEnabledTrue();
    
    boolean existsByMcpId(String mcpId);
    
    void deleteByMcpId(String mcpId);
}