/*
 * Copyright 2024-2026 Luoshen Team
 */
package io.luoshen.admin.exception;

/**
 * 资源未找到异常
 */
public class ResourceNotFoundException extends BusinessException {
    
    public ResourceNotFoundException(String resource, String id) {
        super(String.format("%s 不存在: %s", resource, id));
    }
    
    public ResourceNotFoundException(String message) {
        super(message);
    }
}
