/*
 * Copyright 2024-2026 Luoshen Team
 */
package io.luoshen.admin.service;

import io.luoshen.admin.model.SkillConfigEntity;
import io.luoshen.admin.repository.SkillConfigRepository;
import io.luoshen.admin.exception.BusinessException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Skill 配置服务
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class SkillConfigService {
    
    private final SkillConfigRepository repository;
    
    @Transactional
    public SkillConfigEntity create(SkillConfigEntity config) {
        if (repository.existsBySkillId(config.getSkillId())) {
            throw new BusinessException("Skill ID 已存在: " + config.getSkillId());
        }
        log.info("创建 Skill: {}", config.getSkillId());
        return repository.save(config);
    }
    
    @Transactional
    public SkillConfigEntity update(String skillId, SkillConfigEntity newConfig) {
        SkillConfigEntity existing = repository.findBySkillId(skillId)
                .orElseThrow(() -> new BusinessException("Skill 不存在: " + skillId));
        
        existing.setName(newConfig.getName());
        existing.setDescription(newConfig.getDescription());
        existing.setContent(newConfig.getContent());
        existing.setFilePath(newConfig.getFilePath());
        existing.setEnabled(newConfig.getEnabled());
        
        log.info("更新 Skill: {}", skillId);
        return repository.save(existing);
    }
    
    @Transactional
    public void delete(String skillId) {
        repository.deleteBySkillId(skillId);
        log.info("删除 Skill: {}", skillId);
    }
    
    public List<SkillConfigEntity> listAll() {
        return repository.findAll();
    }
    
    public SkillConfigEntity get(String skillId) {
        return repository.findBySkillId(skillId)
                .orElseThrow(() -> new BusinessException("Skill 不存在: " + skillId));
    }
    
    public List<SkillConfigEntity> getEnabled() {
        return repository.findByEnabledTrue();
    }
}
