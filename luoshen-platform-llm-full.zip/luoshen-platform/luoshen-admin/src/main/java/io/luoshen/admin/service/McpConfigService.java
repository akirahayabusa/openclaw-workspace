/*
 * Copyright 2024-2026 Luoshen Team
 */
package io.luoshen.admin.service;

import io.luoshen.admin.model.McpConfigEntity;
import io.luoshen.admin.repository.McpConfigRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * MCP 配置服务
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class McpConfigService {
    
    private final McpConfigRepository repository;
    
    @Transactional
    public McpConfigEntity create(McpConfigEntity config) {
        if (repository.existsByMcpId(config.getMcpId())) {
            throw new IllegalArgumentException("MCP ID 已存在: " + config.getMcpId());
        }
        log.info("创建 MCP: {}", config.getMcpId());
        return repository.save(config);
    }
    
    @Transactional
    public McpConfigEntity update(String mcpId, McpConfigEntity newConfig) {
        McpConfigEntity existing = repository.findByMcpId(mcpId)
                .orElseThrow(() -> new IllegalArgumentException("MCP 不存在: " + mcpId));
        
        existing.setName(newConfig.getName());
        existing.setTransportType(newConfig.getTransportType());
        existing.setCommand(newConfig.getCommand());
        existing.setUrl(newConfig.getUrl());
        existing.setArgsJson(newConfig.getArgsJson());
        existing.setHeadersJson(newConfig.getHeadersJson());
        existing.setEnabled(newConfig.getEnabled());
        
        log.info("更新 MCP: {}", mcpId);
        return repository.save(existing);
    }
    
    @Transactional
    public void delete(String mcpId) {
        repository.deleteByMcpId(mcpId);
        log.info("删除 MCP: {}", mcpId);
    }
    
    public List<McpConfigEntity> listAll() {
        return repository.findAll();
    }
    
    public McpConfigEntity get(String mcpId) {
        return repository.findByMcpId(mcpId)
                .orElseThrow(() -> new IllegalArgumentException("MCP 不存在: " + mcpId));
    }
    
    public List<McpConfigEntity> getEnabled() {
        return repository.findByEnabledTrue();
    }
}
