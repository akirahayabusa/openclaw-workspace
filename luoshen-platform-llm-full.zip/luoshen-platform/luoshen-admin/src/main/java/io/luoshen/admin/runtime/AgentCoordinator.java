/*
 * Copyright 2024-2026 Luoshen Team
 */
package io.luoshen.admin.runtime;

import io.agentscope.core.ReActAgent;
import io.agentscope.core.memory.InMemoryMemory;
import io.agentscope.core.model.DashScopeChatModel;
import io.agentscope.core.formatter.dashscope.DashScopeChatFormatter;
import io.agentscope.core.tool.Toolkit;
import io.luoshen.admin.llm.LLMModelFactory;
import io.luoshen.admin.model.AgentConfigEntity;
import io.luoshen.admin.repository.AgentConfigRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * Agent 协调器（ATOA 协议）
 * 
 * 实现 Leader → Core → Sub 三级协作
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AgentCoordinator {
    
    private final AgentConfigRepository agentConfigRepository;
    private final LLMModelFactory llmModelFactory;
    private final SkillRuntimeService skillRuntimeService;
    private final McpRuntimeService mcpRuntimeService;
    
    /**
     * 构建完整的 Agent 协作树
     * 
     * @param leaderId Leader Agent ID
     * @return 完整配置的 Leader Agent（包含子 Agent）
     */
    public ReActAgent buildAgentTree(String leaderId) {
        log.info("构建 Agent 协作树: {}", leaderId);
        
        // 获取 Leader 配置
        AgentConfigEntity leaderConfig = agentConfigRepository.findByAgentId(leaderId)
                .orElseThrow(() -> new IllegalArgumentException("Leader Agent 不存在: " + leaderId));
        
        if (!"LEADER".equals(leaderConfig.getType())) {
            throw new IllegalArgumentException("Agent 不是 Leader 类型: " + leaderId);
        }
        
        // 构建 Leader Agent
        return buildAgentWithSubAgents(leaderConfig);
    }
    
    /**
     * 递归构建 Agent 及其子 Agent
     */
    private ReActAgent buildAgentWithSubAgents(AgentConfigEntity config) {
        log.debug("构建 Agent: {} (type: {})", config.getAgentId(), config.getType());
        
        // 1. 创建模型
        DashScopeChatModel model = (DashScopeChatModel) llmModelFactory.createModel(config.getModelName());
        
        // 2. 创建工具包
        Toolkit toolkit = new Toolkit();
        
        // 2.1 加载技能
        loadSkills(config, toolkit);
        
        // 2.2 加载 MCP
        loadMcpServers(config, toolkit);
        
        // 2.3 加载子 Agent（递归）
        loadSubAgents(config, toolkit);
        
        // 3. 创建 Agent
        ReActAgent agent = ReActAgent.builder()
                .name(config.getName())
                .sysPrompt(config.getSystemPrompt())
                .model(model)
                .toolkit(toolkit)
                .memory(new InMemoryMemory())
                .build();
        
        log.debug("Agent 构建完成: {}", config.getAgentId());
        return agent;
    }
    
    /**
     * 加载技能
     */
    private void loadSkills(AgentConfigEntity config, Toolkit toolkit) {
        List<String> skillIds = parseJsonList(config.getSkillsJson());
        for (String skillId : skillIds) {
            skillRuntimeService.loadSkillToToolkit(skillId, toolkit);
        }
        if (!skillIds.isEmpty()) {
            log.debug("Agent {} 加载 {} 个技能", config.getAgentId(), skillIds.size());
        }
    }
    
    /**
     * 加载 MCP 服务器
     */
    private void loadMcpServers(AgentConfigEntity config, Toolkit toolkit) {
        List<String> mcpIds = parseJsonList(config.getMcpServersJson());
        for (String mcpId : mcpIds) {
            mcpRuntimeService.loadMcpToToolkit(mcpId, toolkit);
        }
        if (!mcpIds.isEmpty()) {
            log.debug("Agent {} 加载 {} 个 MCP", config.getAgentId(), mcpIds.size());
        }
    }
    
    /**
     * 加载子 Agent（ATOA 协议）
     */
    private void loadSubAgents(AgentConfigEntity config, Toolkit toolkit) {
        // 查找子 Agent
        List<AgentConfigEntity> subAgents = agentConfigRepository.findByParentAgentId(config.getAgentId());
        
        for (AgentConfigEntity subConfig : subAgents) {
            if (!subConfig.getEnabled()) {
                log.debug("子 Agent 已禁用: {}", subConfig.getAgentId());
                continue;
            }
            
            // 递归构建子 Agent 并注册为工具
            toolkit.registration()
                    .subAgent(() -> buildAgentWithSubAgents(subConfig))
                    .apply();
            
            log.info("子 Agent 注册成功: {} → {}", config.getAgentId(), subConfig.getAgentId());
        }
        
        if (!subAgents.isEmpty()) {
            log.debug("Agent {} 注册 {} 个子 Agent", config.getAgentId(), subAgents.size());
        }
    }
    
    /**
     * 获取 Agent 树结构
     */
    public AgentTreeNode getAgentTree(String agentId) {
        AgentConfigEntity config = agentConfigRepository.findByAgentId(agentId)
                .orElseThrow(() -> new IllegalArgumentException("Agent 不存在: " + agentId));
        
        AgentTreeNode node = new AgentTreeNode();
        node.setAgentId(config.getAgentId());
        node.setName(config.getName());
        node.setType(config.getType());
        
        // 递归获取子节点
        List<AgentConfigEntity> children = agentConfigRepository.findByParentAgentId(agentId);
        for (AgentConfigEntity child : children) {
            node.getChildren().add(getAgentTree(child.getAgentId()));
        }
        
        return node;
    }
    
    /**
     * 解析 JSON 列表
     */
    private List<String> parseJsonList(String json) {
        if (json == null || json.isBlank()) {
            return List.of();
        }
        try {
            json = json.trim();
            if (json.startsWith("[") && json.endsWith("]")) {
                json = json.substring(1, json.length() - 1);
                if (json.isBlank()) {
                    return List.of();
                }
                return java.util.Arrays.stream(json.split(","))
                        .map(String::trim)
                        .map(s -> s.replace("\"", ""))
                        .filter(s -> !s.isEmpty())
                        .toList();
            }
            return List.of();
        } catch (Exception e) {
            return List.of();
        }
    }
    
    /**
     * Agent 树节点
     */
    @lombok.Data
    public static class AgentTreeNode {
        private String agentId;
        private String name;
        private String type;
        private List<AgentTreeNode> children = new java.util.ArrayList<>();
    }
}
