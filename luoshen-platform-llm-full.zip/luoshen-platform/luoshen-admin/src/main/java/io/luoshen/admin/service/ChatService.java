/*
 * Copyright 2024-2026 Luoshen Team
 */
package io.luoshen.admin.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.agentscope.core.ReActAgent;
import io.agentscope.core.agent.Event;
import io.agentscope.core.message.Msg;
import io.agentscope.core.message.MsgRole;
import io.agentscope.core.message.TextBlock;
import io.agentscope.core.session.Session;
import io.agentscope.core.state.SimpleSessionKey;
import io.luoshen.admin.model.ChatMessageEntity;
import io.luoshen.admin.repository.ChatMessageRepository;
import io.luoshen.admin.runtime.AgentRuntimeManager;
import io.luoshen.admin.runtime.MemoryPersistenceService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 聊天服务
 * 
 * 使用 AgentRuntimeManager 动态获取 Agent
 * 使用 MemoryPersistenceService 持久化会话
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ChatService {
    
    private final ChatMessageRepository chatMessageRepository;
    private final AgentRuntimeManager agentRuntimeManager;
    private final MemoryPersistenceService memoryPersistenceService;
    private final ObjectMapper objectMapper = new ObjectMapper();
    
    // 运行中的会话
    private final ConcurrentHashMap<String, ReActAgent> runningAgents = new ConcurrentHashMap<>();
    
    /**
     * 聊天（同步响应）
     */
    public Mono<Map<String, Object>> chat(String sessionId, String agentId, String message) {
        return Mono.fromCallable(() -> {
            // 获取 Agent（从缓存或创建新实例）
            ReActAgent agent = agentRuntimeManager.getOrCreateAgent(agentId);
            runningAgents.put(sessionId, agent);
            
            // 加载会话状态
            Session session = memoryPersistenceService.getSession();
            agent.loadIfExists(session, sessionId);
            
            // 创建用户消息
            Msg userMsg = Msg.builder()
                    .name("User")
                    .role(MsgRole.USER)
                    .content(TextBlock.builder().text(message).build())
                    .build();
            
            // 执行对话
            StringBuilder responseBuilder = new StringBuilder();
            List<Event> events = agent.stream(userMsg).collectList().block();
            
            for (Event event : events) {
                if (event.getMessage() != null && event.getMessage().getTextContent() != null) {
                    responseBuilder.append(event.getMessage().getTextContent());
                }
            }
            
            // 保存会话状态
            agent.saveTo(session, sessionId);
            runningAgents.remove(sessionId);
            
            // 保存到数据库
            saveMessage(sessionId, agentId, "user", message);
            saveMessage(sessionId, agentId, "assistant", responseBuilder.toString());
            
            // 返回结果
            Map<String, Object> result = new HashMap<>();
            result.put("sessionId", sessionId);
            result.put("agentId", agentId);
            result.put("response", responseBuilder.toString());
            return result;
        });
    }
    
    /**
     * 流式聊天
     */
    public Flux<ServerSentEvent<String>> chatStream(String sessionId, String agentId, String message) {
        return Flux.create(emitter -> {
            try {
                // 获取 Agent
                ReActAgent agent = agentRuntimeManager.getOrCreateAgent(agentId);
                runningAgents.put(sessionId, agent);
                
                // 加载会话状态
                Session session = memoryPersistenceService.getSession();
                agent.loadIfExists(session, sessionId);
                
                // 创建用户消息
                Msg userMsg = Msg.builder()
                        .name("User")
                        .role(MsgRole.USER)
                        .content(TextBlock.builder().text(message).build())
                        .build();
                
                // 保存用户消息
                saveMessage(sessionId, agentId, "user", message);
                
                // 流式执行
                StringBuilder fullResponse = new StringBuilder();
                agent.stream(userMsg).subscribe(
                        event -> {
                            try {
                                String text = event.getMessage() != null ? event.getMessage().getTextContent() : "";
                                if (text != null && !text.isEmpty()) {
                                    fullResponse.append(text);
                                }
                                
                                Map<String, Object> data = new HashMap<>();
                                data.put("type", event.getType().name());
                                data.put("content", text);
                                data.put("isLast", event.isLast());
                                
                                String json = objectMapper.writeValueAsString(data);
                                emitter.next(ServerSentEvent.<String>builder()
                                        .data(json)
                                        .build());
                                
                                if (event.isLast()) {
                                    // 保存会话状态
                                    agent.saveTo(session, sessionId);
                                    // 保存助手响应
                                    saveMessage(sessionId, agentId, "assistant", fullResponse.toString());
                                    runningAgents.remove(sessionId);
                                    emitter.complete();
                                }
                            } catch (Exception e) {
                                log.error("处理流事件失败", e);
                            }
                        },
                        error -> {
                            log.error("流式对话失败", error);
                            runningAgents.remove(sessionId);
                            emitter.error(error);
                        },
                        () -> {
                            runningAgents.remove(sessionId);
                            emitter.complete();
                        }
                );
            } catch (Exception e) {
                log.error("创建流式对话失败", e);
                runningAgents.remove(sessionId);
                emitter.error(e);
            }
        });
    }
    
    /**
     * 获取历史消息
     */
    public Mono<List<Map<String, Object>>> getHistory(String sessionId) {
        return Mono.fromCallable(() -> {
            List<ChatMessageEntity> messages = chatMessageRepository.findBySessionIdOrderByCreatedAtAsc(sessionId);
            List<Map<String, Object>> result = new ArrayList<>();
            for (ChatMessageEntity msg : messages) {
                Map<String, Object> map = new HashMap<>();
                map.put("role", msg.getRole());
                map.put("content", msg.getContent());
                map.put("createdAt", msg.getCreatedAt());
                result.add(map);
            }
            return result;
        });
    }
    
    /**
     * 清除会话
     */
    public Mono<Void> clearSession(String sessionId) {
        return Mono.fromRunnable(() -> {
            memoryPersistenceService.delete(sessionId);
            chatMessageRepository.deleteBySessionId(sessionId);
            runningAgents.remove(sessionId);
            log.info("清除会话: {}", sessionId);
        });
    }
    
    /**
     * 中断会话
     */
    public boolean interrupt(String sessionId) {
        ReActAgent agent = runningAgents.get(sessionId);
        if (agent != null) {
            agent.interrupt();
            return true;
        }
        return false;
    }
    
    /**
     * 刷新 Agent（配置更新后调用）
     */
    public void refreshAgent(String agentId) {
        agentRuntimeManager.invalidateAgent(agentId);
        log.info("Agent 已刷新: {}", agentId);
    }
    
    /**
     * 保存消息到数据库
     */
    private void saveMessage(String sessionId, String agentId, String role, String content) {
        try {
            ChatMessageEntity entity = new ChatMessageEntity();
            entity.setSessionId(sessionId);
            entity.setAgentId(agentId);
            entity.setRole(role);
            entity.setContent(content);
            chatMessageRepository.save(entity);
        } catch (Exception e) {
            log.error("保存消息失败", e);
        }
    }
}
