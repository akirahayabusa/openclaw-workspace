/*
 * Copyright 2024-2026 Luoshen Team
 */
package io.luoshen.admin.controller;

import io.luoshen.admin.service.ChatService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;

/**
 * 聊天接口
 */
@RestController
@RequestMapping("/api/chat")
@RequiredArgsConstructor
public class ChatController {
    
    private final ChatService chatService;
    
    /**
     * 发送消息（同步响应）
     */
    @PostMapping("/send")
    public Mono<Map<String, Object>> send(@RequestBody ChatRequest request) {
        return chatService.chat(request.getSessionId(), request.getAgentId(), request.getMessage());
    }
    
    /**
     * 发送消息（SSE 流式响应）
     */
    @PostMapping(value = "/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Flux<ServerSentEvent<String>> stream(@RequestBody ChatRequest request) {
        return chatService.chatStream(request.getSessionId(), request.getAgentId(), request.getMessage());
    }
    
    /**
     * 获取会话历史
     */
    @GetMapping("/history/{sessionId}")
    public Mono<List<Map<String, Object>>> getHistory(@PathVariable String sessionId) {
        return chatService.getHistory(sessionId);
    }
    
    /**
     * 清除会话
     */
    @DeleteMapping("/session/{sessionId}")
    public Mono<Void> clearSession(@PathVariable String sessionId) {
        return chatService.clearSession(sessionId);
    }
    
    /**
     * 聊天请求
     */
    @lombok.Data
    public static class ChatRequest {
        private String sessionId;
        private String agentId;
        private String message;
    }
}
