/*
 * Copyright 2024-2026 Luoshen Team
 */
package io.luoshen.admin.runtime;

import io.agentscope.core.tool.Toolkit;
import io.luoshen.admin.model.McpConfigEntity;
import io.luoshen.admin.repository.McpConfigRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * MCP 运行时服务
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class McpRuntimeService {
    
    private final McpConfigRepository mcpConfigRepository;
    
    /**
     * 加载 MCP 工具到 Toolkit
     */
    public void loadMcpToToolkit(String mcpId, Toolkit toolkit) {
        try {
            Optional<McpConfigEntity> configOpt = mcpConfigRepository.findByMcpId(mcpId);
            
            if (configOpt.isEmpty()) {
                log.warn("MCP 配置不存在: {}", mcpId);
                return;
            }
            
            McpConfigEntity config = configOpt.get();
            
            if (!config.getEnabled()) {
                log.warn("MCP 已禁用: {}", mcpId);
                return;
            }
            
            // TODO: 实现 MCP 连接和工具注册
            // 当前版本只记录日志，后续集成 AgentScope 的 McpClient
            log.info("MCP 加载成功: {} ({}:{})", mcpId, config.getTransportType(), 
                    config.getCommand() != null ? config.getCommand() : config.getUrl());
            
        } catch (Exception e) {
            log.error("加载 MCP 失败: {}", mcpId, e);
        }
    }
}
