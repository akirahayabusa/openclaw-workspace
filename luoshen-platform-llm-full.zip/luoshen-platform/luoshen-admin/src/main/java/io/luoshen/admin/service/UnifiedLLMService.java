/*
 * Copyright 2024-2026 Luoshen Team
 */
package io.luoshen.admin.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.luoshen.admin.llm.LLMModelFactory;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 统一 LLM 调用服务
 * 支持多个提供商：DashScope、火山方舟、智谱 AI、OpenAI、Zora
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class UnifiedLLMService {
    
    private final LLMModelFactory modelFactory;
    private final ObjectMapper objectMapper = new ObjectMapper();
    
    /**
     * 发送聊天请求（同步）
     */
    public Mono<String> chat(String sessionId, String agentId, String message) {
        return chat(sessionId, agentId, message, false).next();
    }
    
    /**
     * 发送聊天请求（流式）
     */
    public Flux<String> chatStream(String sessionId, String agentId, String message) {
        return chat(sessionId, agentId, message, true);
    }
    
    /**
     * 核心聊天逻辑
     */
    private Flux<String> chat(String sessionId, String agentId, String message, boolean stream) {
        try {
            // 1. 获取 Agent 配置
            Map<String, Object> agentInfo = getAgentInfo(agentId);
            String modelName = (String) agentInfo.get("modelName");
            String systemPrompt = (String) agentInfo.get("systemPrompt");
            
            // 2. 创建模型配置
            Map<String, Object> modelConfig = modelFactory.createModelConfig(modelName);
            String provider = (String) modelConfig.get("provider");
            String actualModel = (String) modelConfig.get("modelName");
            String apiKey = (String) modelConfig.get("apiKey");
            String endpoint = (String) modelConfig.get("endpoint");
            
            // 3. 检查 API Key
            if (apiKey == null || apiKey.isEmpty()) {
                return Flux.error(new RuntimeException("未配置 " + provider + " 的 API Key"));
            }
            
            // 4. 根据提供商选择调用方式
            switch (provider) {
                case "dashscope":
                    return callDashScope(actualModel, apiKey, systemPrompt, message, stream);
                case "volcengine":
                    return callVolcengine(actualModel, apiKey, endpoint, systemPrompt, message, stream);
                case "zhipu":
                    return callZhipu(actualModel, apiKey, endpoint, systemPrompt, message, stream);
                case "openai":
                    return callOpenAICompatible(actualModel, apiKey, endpoint, systemPrompt, message, stream);
                case "zora":
                    return callOpenAICompatible(actualModel, apiKey, endpoint, systemPrompt, message, stream);
                default:
                    return Flux.error(new RuntimeException("不支持的提供商: " + provider));
            }
            
        } catch (Exception e) {
            log.error("聊天请求失败", e);
            return Flux.error(e);
        }
    }
    
    /**
     * 调用 DashScope (阿里云灵积)
     */
    private Flux<String> callDashScope(String model, String apiKey, String systemPrompt, 
                                        String message, boolean stream) {
        // 这里使用 AgentScope 原生的 DashScopeChatModel
        // 由 ChatService 处理
        return Flux.error(new RuntimeException("DashScope 请使用 ChatService"));
    }
    
    /**
     * 调用火山方舟
     */
    private Flux<String> callVolcengine(String model, String apiKey, String endpoint,
                                         String systemPrompt, String message, boolean stream) {
        WebClient client = WebClient.builder()
                .baseUrl(endpoint)
                .defaultHeader(HttpHeaders.AUTHORIZATION, "Bearer " + apiKey)
                .build();
        
        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("model", model);
        requestBody.put("stream", stream);
        
        Map<String, String> msg = new HashMap<>();
        msg.put("role", "user");
        msg.put("content", message);
        requestBody.put("messages", List.of(msg));
        
        if (stream) {
            return client.post()
                    .uri("/chat/completions")
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(requestBody)
                    .retrieve()
                    .bodyToFlux(String.class)
                    .map(this::extractSSEData)
                    .filter(data -> !data.isEmpty())
                    .doOnError(e -> log.error("火山方舟流式调用失败", e));
        } else {
            return client.post()
                    .uri("/chat/completions")
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(requestBody)
                    .retrieve()
                    .bodyToMono(String.class)
                    .map(this::extractContent)
                    .flux()
                    .doOnError(e -> log.error("火山方舟同步调用失败", e));
        }
    }
    
    /**
     * 调用智谱 AI (GLM)
     */
    private Flux<String> callZhipu(String model, String apiKey, String endpoint,
                                     String systemPrompt, String message, boolean stream) {
        // 智谱 API Key 格式: id.secret
        WebClient client = WebClient.builder()
                .baseUrl(endpoint)
                .defaultHeader(HttpHeaders.AUTHORIZATION, "Bearer " + apiKey)
                .build();
        
        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("model", model);
        requestBody.put("stream", stream);
        
        Map<String, String> systemMsg = new HashMap<>();
        systemMsg.put("role", "system");
        systemMsg.put("content", systemPrompt != null ? systemPrompt : "你是一个有帮助的AI助手。");
        
        Map<String, String> userMsg = new HashMap<>();
        userMsg.put("role", "user");
        userMsg.put("content", message);
        
        requestBody.put("messages", List.of(systemMsg, userMsg));
        
        if (stream) {
            return client.post()
                    .uri("/chat/completions")
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(requestBody)
                    .retrieve()
                    .bodyToFlux(String.class)
                    .map(this::extractSSEData)
                    .filter(data -> !data.isEmpty())
                    .doOnError(e -> log.error("智谱 AI 流式调用失败", e));
        } else {
            return client.post()
                    .uri("/chat/completions")
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(requestBody)
                    .retrieve()
                    .bodyToMono(String.class)
                    .map(this::extractContent)
                    .flux()
                    .doOnError(e -> log.error("智谱 AI 同步调用失败", e));
        }
    }
    
    /**
     * 调用 OpenAI 兼容接口 (OpenAI / Zora)
     */
    private Flux<String> callOpenAICompatible(String model, String apiKey, String endpoint,
                                               String systemPrompt, String message, boolean stream) {
        WebClient client = WebClient.builder()
                .baseUrl(endpoint)
                .defaultHeader(HttpHeaders.AUTHORIZATION, "Bearer " + apiKey)
                .defaultHeader(HttpHeaders.USER_AGENT, "LuoshenPlatform/1.0")
                .build();
        
        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("model", model);
        requestBody.put("stream", stream);
        
        Map<String, String> systemMsg = new HashMap<>();
        systemMsg.put("role", "system");
        systemMsg.put("content", systemPrompt != null ? systemPrompt : "你是一个有帮助的AI助手。");
        
        Map<String, String> userMsg = new HashMap<>();
        userMsg.put("role", "user");
        userMsg.put("content", message);
        
        requestBody.put("messages", List.of(systemMsg, userMsg));
        requestBody.put("temperature", 0.7);
        requestBody.put("max_tokens", 2000);
        
        if (stream) {
            return client.post()
                    .uri("/chat/completions")
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(requestBody)
                    .retrieve()
                    .bodyToFlux(String.class)
                    .map(this::extractSSEData)
                    .filter(data -> !data.isEmpty())
                    .doOnError(e -> log.error("OpenAI 兼容接口流式调用失败", e));
        } else {
            return client.post()
                    .uri("/chat/completions")
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(requestBody)
                    .retrieve()
                    .bodyToMono(String.class)
                    .map(this::extractContent)
                    .flux()
                    .doOnError(e -> log.error("OpenAI 兼容接口同步调用失败", e));
        }
    }
    
    /**
     * 提取 SSE 数据
     */
    private String extractSSEData(String sseLine) {
        if (sseLine == null || !sseLine.startsWith("data: ")) {
            return "";
        }
        String data = sseLine.substring(6);
        if ("[DONE]".equals(data.trim())) {
            return "";
        }
        try {
            JsonNode root = objectMapper.readTree(data);
            JsonNode choices = root.get("choices");
            if (choices != null && choices.isArray() && choices.size() > 0) {
                JsonNode delta = choices.get(0).get("delta");
                if (delta != null && delta.has("content")) {
                    return delta.get("content").asText();
                }
            }
        } catch (Exception e) {
            log.debug("解析 SSE 数据失败: {}", sseLine, e);
        }
        return "";
    }
    
    /**
     * 提取响应内容
     */
    private String extractContent(String jsonResponse) {
        try {
            JsonNode root = objectMapper.readTree(jsonResponse);
            JsonNode choices = root.get("choices");
            if (choices != null && choices.isArray() && choices.size() > 0) {
                JsonNode message = choices.get(0).get("message");
                if (message != null && message.has("content")) {
                    return message.get("content").asText();
                }
            }
        } catch (Exception e) {
            log.error("解析响应失败: {}", jsonResponse, e);
        }
        return "解析响应失败";
    }
    
    /**
     * 获取 Agent 信息 (模拟，实际应该从数据库或缓存获取)
     */
    private Map<String, Object> getAgentInfo(String agentId) {
        Map<String, Object> info = new HashMap<>();
        info.put("agentId", agentId);
        info.put("modelName", "qwen-plus");
        info.put("systemPrompt", "你是一个有帮助的AI助手。");
        return info;
    }
}
