/*
 * Copyright 2024-2026 Luoshen Team
 */
package io.luoshen.admin.runtime;

import io.agentscope.core.session.JsonSession;
import io.agentscope.core.session.Session;
import io.agentscope.core.state.SessionKey;
import io.agentscope.core.state.SimpleSessionKey;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * 会话持久化服务
 * 
 * 使用 JsonSession 持久化对话状态到文件系统
 */
@Slf4j
@Service
public class MemoryPersistenceService {
    
    @Value("${luoshen.sessions.path:./data/sessions}")
    private String sessionsPath;
    
    private Session session;
    
    @PostConstruct
    public void init() {
        try {
            Path path = Paths.get(sessionsPath);
            if (!Files.exists(path)) {
                Files.createDirectories(path);
                log.info("创建会话目录: {}", path);
            }
            
            this.session = new JsonSession(path);
            log.info("MemoryPersistenceService 初始化完成, 路径: {}", path);
        } catch (Exception e) {
            log.error("初始化会话存储失败，使用内存存储", e);
            // 降级到内存存储
            this.session = new io.agentscope.core.session.InMemorySession();
        }
    }
    
    /**
     * 获取 Session 实例
     */
    public Session getSession() {
        return session;
    }
    
    /**
     * 创建会话 Key
     */
    public SessionKey createKey(String sessionId) {
        return SimpleSessionKey.of(sessionId);
    }
    
    /**
     * 检查会话是否存在
     */
    public boolean exists(String sessionId) {
        return session.exists(createKey(sessionId));
    }
    
    /**
     * 删除会话
     */
    public void delete(String sessionId) {
        session.delete(createKey(sessionId));
        log.info("会话已删除: {}", sessionId);
    }
    
    /**
     * 列出所有会话
     */
    public Set<String> listSessions() {
        return session.listSessionKeys().stream()
                .map(SessionKey::toString)
                .collect(Collectors.toSet());
    }
    
    /**
     * 清理过期会话（可选）
     */
    public void cleanupExpiredSessions(int maxAgeHours) {
        // TODO: 实现过期会话清理
        log.info("清理过期会话（maxAge={}小时）", maxAgeHours);
    }
}
