/*
 * Copyright 2024-2026 Luoshen Team
 */
package io.luoshen.admin.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

/**
 * Agent 配置实体
 */
@Data
@Entity
@Table(name = "agent_config")
public class AgentConfigEntity {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(unique = true, nullable = false, length = 100)
    private String agentId;
    
    @Column(nullable = false, length = 200)
    private String name;
    
    @Column(columnDefinition = "TEXT")
    private String description;
    
    @Column(nullable = false, length = 20)
    private String type; // LEADER, CORE, SUB
    
    @Column(length = 100)
    private String parentAgentId;
    
    @Column(columnDefinition = "TEXT")
    private String systemPrompt;
    
    @Column(length = 100)
    private String modelName;
    
    @Column(columnDefinition = "TEXT")
    private String toolsJson;
    
    @Column(columnDefinition = "TEXT")
    private String skillsJson;
    
    @Column(columnDefinition = "TEXT")
    private String mcpServersJson;
    
    @Column(columnDefinition = "TEXT")
    private String subAgentsJson;
    
    @Column(nullable = false)
    private Boolean enabled = true;
    
    @Column(updatable = false)
    private LocalDateTime createdAt;
    
    private LocalDateTime updatedAt;
    
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = createdAt;
    }
    
    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
