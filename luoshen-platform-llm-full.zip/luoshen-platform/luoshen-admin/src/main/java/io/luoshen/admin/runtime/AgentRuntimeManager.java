/*
 * Copyright 2024-2026 Luoshen Team
 */
package io.luoshen.admin.runtime;

import io.agentscope.core.ReActAgent;
import io.agentscope.core.memory.InMemoryMemory;
import io.agentscope.core.model.DashScopeChatModel;
import io.agentscope.core.formatter.dashscope.DashScopeChatFormatter;
import io.agentscope.core.tool.Toolkit;
import io.luoshen.admin.llm.LLMModelFactory;
import io.luoshen.admin.model.AgentConfigEntity;
import io.luoshen.admin.repository.AgentConfigRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Agent 运行时管理器
 * 
 * 管理运行中的 Agent 实例，支持配置热更新
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AgentRuntimeManager {
    
    private final AgentConfigRepository agentConfigRepository;
    private final LLMModelFactory llmModelFactory;
    private final SkillRuntimeService skillRuntimeService;
    private final McpRuntimeService mcpRuntimeService;
    
    // Agent 实例缓存（配置更新时清理）
    private final ConcurrentHashMap<String, ReActAgent> agentCache = new ConcurrentHashMap<>();
    
    /**
     * 获取或创建 Agent
     */
    public ReActAgent getOrCreateAgent(String agentId) {
        return agentCache.computeIfAbsent(agentId, this::createAgent);
    }
    
    /**
     * 清理 Agent 缓存（配置更新时调用）
     */
    public void invalidateAgent(String agentId) {
        ReActAgent removed = agentCache.remove(agentId);
        if (removed != null) {
            log.info("Agent 缓存已清理: {}", agentId);
        }
    }
    
    /**
     * 清理所有缓存
     */
    public void invalidateAll() {
        int size = agentCache.size();
        agentCache.clear();
        log.info("已清理 {} 个 Agent 缓存", size);
    }
    
    /**
     * 创建 Agent
     */
    private ReActAgent createAgent(String agentId) {
        log.info("创建 Agent: {}", agentId);
        
        AgentConfigEntity config = agentConfigRepository.findByAgentId(agentId)
                .orElseThrow(() -> new IllegalArgumentException("Agent 不存在: " + agentId));
        
        if (!config.getEnabled()) {
            throw new IllegalStateException("Agent 已禁用: " + agentId);
        }
        
        // 1. 创建模型
        String modelName = config.getModelName();
        String provider = llmModelFactory.getProvider(modelName);
        
        if (!llmModelFactory.hasApiKey(provider)) {
            throw new IllegalStateException("未配置 " + provider + " 的 API Key");
        }
        
        DashScopeChatModel model = (DashScopeChatModel) llmModelFactory.createModel(modelName);
        
        // 2. 创建工具包
        Toolkit toolkit = new Toolkit();
        
        // 2.1 加载技能
        List<String> skillIds = parseJsonList(config.getSkillsJson());
        for (String skillId : skillIds) {
            skillRuntimeService.loadSkillToToolkit(skillId, toolkit);
        }
        
        // 2.2 加载 MCP 工具
        List<String> mcpIds = parseJsonList(config.getMcpServersJson());
        for (String mcpId : mcpIds) {
            mcpRuntimeService.loadMcpToToolkit(mcpId, toolkit);
        }
        
        // 2.3 加载子 Agent（ATOA 协议）
        List<String> subAgentIds = parseJsonList(config.getSubAgentsJson());
        for (String subAgentId : subAgentIds) {
            registerSubAgent(subAgentId, toolkit);
        }
        
        // 3. 创建 Agent
        ReActAgent agent = ReActAgent.builder()
                .name(config.getName())
                .sysPrompt(config.getSystemPrompt())
                .model(model)
                .toolkit(toolkit)
                .memory(new InMemoryMemory())
                .build();
        
        log.info("Agent 创建成功: {} (provider: {}, skills: {}, mcp: {}, subAgents: {})", 
                agentId, provider, skillIds.size(), mcpIds.size(), subAgentIds.size());
        
        return agent;
    }
    
    /**
     * 注册子 Agent（ATOA 协议）
     */
    private void registerSubAgent(String subAgentId, Toolkit toolkit) {
        try {
            // 获取子 Agent 配置
            Optional<AgentConfigEntity> subConfigOpt = agentConfigRepository.findByAgentId(subAgentId);
            if (subConfigOpt.isEmpty()) {
                log.warn("子 Agent 不存在: {}", subAgentId);
                return;
            }
            
            AgentConfigEntity subConfig = subConfigOpt.get();
            if (!subConfig.getEnabled()) {
                log.warn("子 Agent 已禁用: {}", subAgentId);
                return;
            }
            
            // 注册为 subAgent 工具
            toolkit.registration()
                    .subAgent(() -> getOrCreateAgent(subAgentId))
                    .apply();
            
            log.info("子 Agent 注册成功: {}", subAgentId);
        } catch (Exception e) {
            log.error("注册子 Agent 失败: {}", subAgentId, e);
        }
    }
    
    /**
     * 解析 JSON 列表
     */
    private List<String> parseJsonList(String json) {
        if (json == null || json.isBlank()) {
            return List.of();
        }
        try {
            // 简单的 JSON 数组解析
            json = json.trim();
            if (json.startsWith("[") && json.endsWith("]")) {
                json = json.substring(1, json.length() - 1);
                if (json.isBlank()) {
                    return List.of();
                }
                return java.util.Arrays.stream(json.split(","))
                        .map(String::trim)
                        .map(s -> s.replace("\"", ""))
                        .filter(s -> !s.isEmpty())
                        .toList();
            }
            return List.of();
        } catch (Exception e) {
            log.warn("解析 JSON 列表失败: {}", json, e);
            return List.of();
        }
    }
    
    /**
     * 获取缓存的 Agent 数量
     */
    public int getCacheSize() {
        return agentCache.size();
    }
}
