/*
 * Copyright 2024-2026 Luoshen Team
 */
package io.luoshen.admin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 洛神管理后台启动类
 */
@SpringBootApplication
public class LuoshenAdminApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(LuoshenAdminApplication.class, args);
    }
}
