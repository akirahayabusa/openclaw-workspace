/*
 * Copyright 2024-2026 Luoshen Team
 */
package io.luoshen.admin.controller;

import io.luoshen.admin.model.McpConfigEntity;
import io.luoshen.admin.service.McpConfigService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * MCP 管理接口
 */
@RestController
@RequestMapping("/api/mcp")
@RequiredArgsConstructor
public class McpController {
    
    private final McpConfigService mcpConfigService;
    
    /**
     * 创建 MCP 配置
     */
    @PostMapping
    public ResponseEntity<McpConfigEntity> create(@RequestBody McpConfigEntity config) {
        return ResponseEntity.ok(mcpConfigService.create(config));
    }
    
    /**
     * 获取所有 MCP 配置
     */
    @GetMapping
    public ResponseEntity<List<McpConfigEntity>> list() {
        return ResponseEntity.ok(mcpConfigService.listAll());
    }
    
    /**
     * 获取 MCP 配置详情
     */
    @GetMapping("/{mcpId}")
    public ResponseEntity<McpConfigEntity> get(@PathVariable String mcpId) {
        return ResponseEntity.ok(mcpConfigService.get(mcpId));
    }
    
    /**
     * 更新 MCP 配置
     */
    @PutMapping("/{mcpId}")
    public ResponseEntity<McpConfigEntity> update(
            @PathVariable String mcpId,
            @RequestBody McpConfigEntity config) {
        return ResponseEntity.ok(mcpConfigService.update(mcpId, config));
    }
    
    /**
     * 删除 MCP 配置
     */
    @DeleteMapping("/{mcpId}")
    public ResponseEntity<Void> delete(@PathVariable String mcpId) {
        mcpConfigService.delete(mcpId);
        return ResponseEntity.noContent().build();
    }
}
