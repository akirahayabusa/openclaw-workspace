/*
 * Copyright 2024-2026 Luoshen Team
 */
package io.luoshen.admin.service;

import io.luoshen.admin.model.AgentConfigEntity;
import io.luoshen.admin.repository.AgentConfigRepository;
import io.luoshen.admin.exception.ResourceNotFoundException;
import io.luoshen.admin.exception.BusinessException;
import io.luoshen.admin.runtime.AgentRuntimeManager;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * Agent 配置服务
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AgentConfigService {
    
    private final AgentConfigRepository repository;
    private final AgentRuntimeManager agentRuntimeManager;
    
    @Transactional
    public AgentConfigEntity create(AgentConfigEntity config) {
        if (repository.existsByAgentId(config.getAgentId())) {
            throw new BusinessException("Agent ID 已存在: " + config.getAgentId());
        }
        
        validateHierarchy(config);
        AgentConfigEntity saved = repository.save(config);
        log.info("创建 Agent: {}", config.getAgentId());
        return saved;
    }
    
    @Transactional
    public AgentConfigEntity update(String agentId, AgentConfigEntity newConfig) {
        AgentConfigEntity existing = repository.findByAgentId(agentId)
                .orElseThrow(() -> new ResourceNotFoundException("Agent 不存在: " + agentId));
        
        existing.setName(newConfig.getName());
        existing.setDescription(newConfig.getDescription());
        existing.setSystemPrompt(newConfig.getSystemPrompt());
        existing.setModelName(newConfig.getModelName());
        existing.setType(newConfig.getType());
        existing.setToolsJson(newConfig.getToolsJson());
        existing.setSkillsJson(newConfig.getSkillsJson());
        existing.setMcpServersJson(newConfig.getMcpServersJson());
        existing.setSubAgentsJson(newConfig.getSubAgentsJson());
        existing.setParentAgentId(newConfig.getParentAgentId());
        existing.setEnabled(newConfig.getEnabled());
        
        validateHierarchy(existing);
        
        // 清理运行时缓存（配置更新后立即生效）
        agentRuntimeManager.invalidateAgent(agentId);
        
        log.info("更新 Agent: {}", agentId);
        return repository.save(existing);
    }
    
    @Transactional
    public void delete(String agentId) {
        List<AgentConfigEntity> children = repository.findByParentAgentId(agentId);
        if (!children.isEmpty()) {
            throw new BusinessException("该 Agent 有子 Agent，不能删除");
        }
        
        // 清理缓存
        agentRuntimeManager.invalidateAgent(agentId);
        
        repository.deleteByAgentId(agentId);
        log.info("删除 Agent: {}", agentId);
    }
    
    public List<AgentConfigEntity> listAll() {
        return repository.findAll();
    }
    
    public AgentConfigEntity get(String agentId) {
        return repository.findByAgentId(agentId)
                .orElseThrow(() -> new ResourceNotFoundException("Agent 不存在: " + agentId));
    }
    
    public List<AgentConfigEntity> getByType(String type) {
        return repository.findByType(type);
    }
    
    public List<AgentConfigEntity> getChildren(String parentAgentId) {
        return repository.findByParentAgentId(parentAgentId);
    }
    
    public Map<String, Object> getAgentTree() {
        Map<String, Object> tree = new LinkedHashMap<>();
        
        // Leader
        List<AgentConfigEntity> leaders = repository.findByType("LEADER");
        tree.put("leader", leaders.isEmpty() ? null : leaders.get(0));
        
        // Core Agents
        List<AgentConfigEntity> coreAgents = repository.findByType("CORE");
        List<Map<String, Object>> coreNodes = new ArrayList<>();
        
        for (AgentConfigEntity core : coreAgents) {
            Map<String, Object> node = new LinkedHashMap<>();
            node.put("agent", core);
            node.put("subAgents", repository.findByParentAgentId(core.getAgentId()));
            coreNodes.add(node);
        }
        
        tree.put("coreAgents", coreNodes);
        return tree;
    }
    
    private void validateHierarchy(AgentConfigEntity config) {
        String type = config.getType();
        String parentId = config.getParentAgentId();
        
        if ("LEADER".equals(type) && parentId != null) {
            log.warn("Leader Agent 不应该有父 Agent: {}", config.getAgentId());
        } else if ("CORE".equals(type)) {
            if (parentId == null) {
                throw new BusinessException("Core Agent 必须指定 parentAgentId");
            }
            AgentConfigEntity parent = repository.findByAgentId(parentId).orElse(null);
            if (parent == null || !"LEADER".equals(parent.getType())) {
                throw new BusinessException("Core Agent 的父 Agent 必须是 Leader 类型");
            }
        } else if ("SUB".equals(type)) {
            if (parentId == null) {
                throw new BusinessException("Sub Agent 必须指定 parentAgentId");
            }
            AgentConfigEntity parent = repository.findByAgentId(parentId).orElse(null);
            if (parent == null || !"CORE".equals(parent.getType())) {
                throw new BusinessException("Sub Agent 的父 Agent 必须是 CORE 类型");
            }
        }
    }
}
