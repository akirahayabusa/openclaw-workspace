/*
 * Copyright 2024-2026 Luoshen Team
 */
package io.luoshen.admin.controller;

import io.luoshen.admin.model.SkillConfigEntity;
import io.luoshen.admin.service.SkillConfigService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Skill 管理接口
 */
@RestController
@RequestMapping("/api/skills")
@RequiredArgsConstructor
public class SkillController {
    
    private final SkillConfigService skillConfigService;
    
    /**
     * 创建 Skill
     */
    @PostMapping
    public ResponseEntity<SkillConfigEntity> create(@RequestBody SkillConfigEntity config) {
        return ResponseEntity.ok(skillConfigService.create(config));
    }
    
    /**
     * 获取所有 Skill
     */
    @GetMapping
    public ResponseEntity<List<SkillConfigEntity>> list() {
        return ResponseEntity.ok(skillConfigService.listAll());
    }
    
    /**
     * 获取 Skill 详情
     */
    @GetMapping("/{skillId}")
    public ResponseEntity<SkillConfigEntity> get(@PathVariable String skillId) {
        return ResponseEntity.ok(skillConfigService.get(skillId));
    }
    
    /**
     * 更新 Skill
     */
    @PutMapping("/{skillId}")
    public ResponseEntity<SkillConfigEntity> update(
            @PathVariable String skillId,
            @RequestBody SkillConfigEntity config) {
        return ResponseEntity.ok(skillConfigService.update(skillId, config));
    }
    
    /**
     * 删除 Skill
     */
    @DeleteMapping("/{skillId}")
    public ResponseEntity<Void> delete(@PathVariable String skillId) {
        skillConfigService.delete(skillId);
        return ResponseEntity.noContent().build();
    }
}
