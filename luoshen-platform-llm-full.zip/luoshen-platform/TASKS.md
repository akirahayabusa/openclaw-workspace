# 洛神平台开发任务

## 当前任务：Phase 1 - 核心模块开发

### 目标
基于 AgentScope-Java 框架，构建洛神平台的核心模块。

### 任务清单

#### 1. 项目基础结构
- [ ] 创建父 POM（pom.xml）
- [ ] 创建 luoshen-core 模块
- [ ] 创建 luoshen-admin 模块
- [ ] 创建 luoshen-leader 模块
- [ ] 配置依赖管理

#### 2. luoshen-core 模块
- [ ] AgentFactory：动态创建 Agent
- [ ] SkillLoader：从文件系统加载技能
- [ ] McpManager：管理 MCP 连接
- [ ] SessionManager：会话持久化
- [ ] MemoryManager：记忆管理

#### 3. luoshen-admin 模块
- [ ] AgentController：Agent CRUD API
- [ ] SkillController：Skill CRUD API
- [ ] McpController：MCP 管理 API
- [ ] SessionController：会话管理 API
- [ ] DashboardController：系统概览 API

#### 4. luoshen-leader 模块
- [ ] LeaderAgentApplication：启动类
- [ ] LeaderAgent：主控智能体实现
- [ ] TaskDispatcher：任务分发器

### 参考
- AgentScope-Java 示例：../agentscope-java/agentscope-examples/hitl-chat
- 原有 demo：../luoshen-demo

### 开发要求
1. 直接使用 AgentScope-Java 原生 API
2. 参考hitl-chat 示例的实现方式
3. 保持代码简洁，避免过度设计
4. 添加必要的注释和文档
