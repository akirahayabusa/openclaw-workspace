/*
 * Copyright 2024-2026 Luoshen Team
 */
package io.luoshen.core.manager;

import io.agentscope.core.tool.Toolkit;
import io.agentscope.core.tool.mcp.McpClientBuilder;
import io.agentscope.core.tool.mcp.McpClientWrapper;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * MCP 管理器
 * 
 * 管理 MCP (Model Context Protocol) 客户端连接
 * 支持 STDIO、SSE、HTTP 三种传输方式
 */
@Slf4j
public class McpManager {

    private final Map<String, McpClientWrapper> clients = new ConcurrentHashMap<>();
    private final Toolkit toolkit;

    /**
     * 创建 MCP 管理器
     *
     * @param toolkit 工具包（用于注册 MCP 工具）
     */
    public McpManager(Toolkit toolkit) {
        this.toolkit = toolkit;
        log.info("McpManager initialized");
    }

    /**
     * 连接 STDIO 类型的 MCP 服务器
     *
     * @param mcpId   MCP 标识
     * @param command 启动命令
     * @return Mono 完成信号
     */
    public Mono<Void> connectStdio(String mcpId, String command) {
        return connectStdio(mcpId, command, new String[0]);
    }

    /**
     * 连接 STDIO 类型的 MCP 服务器（带参数）
     *
     * @param mcpId   MCP 标识
     * @param command 启动命令
     * @param args    命令参数
     * @return Mono 完成信号
     */
    public Mono<Void> connectStdio(String mcpId, String command, String[] args) {
        log.info("Connecting STDIO MCP: {} with command: {}", mcpId, command);
        
        if (clients.containsKey(mcpId)) {
            return Mono.error(new IllegalArgumentException("MCP already connected: " + mcpId));
        }
        
        McpClientBuilder builder = McpClientBuilder.create(mcpId);
        if (args == null || args.length == 0) {
            builder.stdioTransport(command);
        } else {
            builder.stdioTransport(command, args);
        }
        
        return builder.buildAsync()
                .flatMap(client -> {
                    clients.put(mcpId, client);
                    return toolkit.registerMcpClient(client);
                })
                .doOnSuccess(v -> log.info("STDIO MCP connected: {}", mcpId))
                .doOnError(e -> log.error("Failed to connect STDIO MCP: {}", mcpId, e));
    }

    /**
     * 连接 SSE 类型的 MCP 服务器
     *
     * @param mcpId MCP 标识
     * @param url   SSE URL
     * @return Mono 完成信号
     */
    public Mono<Void> connectSse(String mcpId, String url) {
        log.info("Connecting SSE MCP: {} with URL: {}", mcpId, url);
        
        if (clients.containsKey(mcpId)) {
            return Mono.error(new IllegalArgumentException("MCP already connected: " + mcpId));
        }
        
        return McpClientBuilder.create(mcpId)
                .sseTransport(url)
                .buildAsync()
                .flatMap(client -> {
                    clients.put(mcpId, client);
                    return toolkit.registerMcpClient(client);
                })
                .doOnSuccess(v -> log.info("SSE MCP connected: {}", mcpId))
                .doOnError(e -> log.error("Failed to connect SSE MCP: {}", mcpId, e));
    }

    /**
     * 连接 HTTP 类型的 MCP 服务器
     *
     * @param mcpId MCP 标识
     * @param url   HTTP URL
     * @return Mono 完成信号
     */
    public Mono<Void> connectHttp(String mcpId, String url) {
        log.info("Connecting HTTP MCP: {} with URL: {}", mcpId, url);
        
        if (clients.containsKey(mcpId)) {
            return Mono.error(new IllegalArgumentException("MCP already connected: " + mcpId));
        }
        
        return McpClientBuilder.create(mcpId)
                .streamableHttpTransport(url)
                .buildAsync()
                .flatMap(client -> {
                    clients.put(mcpId, client);
                    return toolkit.registerMcpClient(client);
                })
                .doOnSuccess(v -> log.info("HTTP MCP connected: {}", mcpId))
                .doOnError(e -> log.error("Failed to connect HTTP MCP: {}", mcpId, e));
    }

    /**
     * 断开 MCP 连接
     *
     * @param mcpId MCP 标识
     * @return Mono 完成信号
     */
    public Mono<Void> disconnect(String mcpId) {
        log.info("Disconnecting MCP: {}", mcpId);
        
        McpClientWrapper client = clients.remove(mcpId);
        if (client == null) {
            return Mono.error(new IllegalArgumentException("MCP not found: " + mcpId));
        }
        
        return toolkit.removeMcpClient(mcpId)
                .doOnSuccess(v -> log.info("MCP disconnected: {}", mcpId))
                .doOnError(e -> log.error("Failed to disconnect MCP: {}", mcpId, e));
    }

    /**
     * 获取所有已连接的 MCP 标识
     *
     * @return MCP 标识列表
     */
    public List<String> getConnectedMcps() {
        return List.copyOf(clients.keySet());
    }

    /**
     * 检查 MCP 是否已连接
     *
     * @param mcpId MCP 标识
     * @return 是否已连接
     */
    public boolean isConnected(String mcpId) {
        return clients.containsKey(mcpId);
    }
}
