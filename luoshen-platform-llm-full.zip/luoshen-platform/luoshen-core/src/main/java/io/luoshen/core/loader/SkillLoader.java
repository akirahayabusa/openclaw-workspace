/*
 * Copyright 2024-2026 Luoshen Team
 */
package io.luoshen.core.loader;

import io.agentscope.core.skill.AgentSkill;
import io.agentscope.core.skill.repository.FileSystemSkillRepository;
import lombok.extern.slf4j.Slf4j;

import java.nio.file.Path;
import java.util.List;

/**
 * 技能加载器
 * 
 * 从文件系统加载 Markdown 格式的技能定义
 * 基于 AgentScope-Java 的 FileSystemSkillRepository
 */
@Slf4j
public class SkillLoader {

    private final FileSystemSkillRepository repository;

    /**
     * 创建技能加载器
     *
     * @param skillsPath 技能文件目录路径
     */
    public SkillLoader(Path skillsPath) {
        this.repository = new FileSystemSkillRepository(skillsPath, false);
        log.info("SkillLoader initialized with path: {}", skillsPath);
    }

    /**
     * 加载指定名称的技能
     *
     * @param skillName 技能名称
     * @return 技能实例（如果存在），否则返回 null
     */
    public AgentSkill loadSkill(String skillName) {
        log.info("Loading skill: {}", skillName);
        AgentSkill skill = repository.getSkill(skillName);
        if (skill != null) {
            log.info("Skill loaded successfully: {}", skillName);
        } else {
            log.warn("Skill not found: {}", skillName);
        }
        return skill;
    }

    /**
     * 列出所有可用的技能名称
     *
     * @return 技能名称列表
     */
    public List<String> listSkills() {
        return repository.getAllSkillNames();
    }

    /**
     * 检查技能是否存在
     *
     * @param skillName 技能名称
     * @return 是否存在
     */
    public boolean exists(String skillName) {
        return repository.skillExists(skillName);
    }
    
    /**
     * 获取所有技能
     *
     * @return 技能列表
     */
    public List<AgentSkill> getAllSkills() {
        return repository.getAllSkills();
    }
}
