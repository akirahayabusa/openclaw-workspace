/*
 * Copyright 2024-2026 Luoshen Team
 */
package io.luoshen.core.factory;

import io.agentscope.core.ReActAgent;
import io.agentscope.core.memory.InMemoryMemory;
import io.agentscope.core.memory.Memory;
import io.agentscope.core.model.Model;
import io.agentscope.core.tool.Toolkit;
import lombok.Builder;
import lombok.extern.slf4j.Slf4j;

/**
 * Agent 工厂
 * 
 * 用于动态创建 ReActAgent 实例
 * 基于 AgentScope-Java 原生 API
 */
@Slf4j
public class AgentFactory {

    /**
     * 创建 Agent 配置
     */
    @Builder
    public static class AgentConfig {
        private String name;
        private String systemPrompt;
        private Model model;
        private Toolkit toolkit;
        private Memory memory;
    }

    /**
     * 创建 ReActAgent
     *
     * @param config Agent 配置
     * @return ReActAgent 实例
     */
    public static ReActAgent createAgent(AgentConfig config) {
        log.info("Creating agent: {}", config.name);
        
        ReActAgent.Builder builder = ReActAgent.builder()
                .name(config.name)
                .sysPrompt(config.systemPrompt);
        
        // 设置模型
        if (config.model != null) {
            builder.model(config.model);
        }
        
        // 设置工具包
        if (config.toolkit != null) {
            builder.toolkit(config.toolkit);
        }
        
        // 设置记忆（默认使用内存记忆）
        builder.memory(config.memory != null ? config.memory : new InMemoryMemory());
        
        ReActAgent agent = builder.build();
        log.info("Agent created successfully: {}", config.name);
        
        return agent;
    }

    /**
     * 使用默认配置创建 Agent
     *
     * @param name Agent 名称
     * @param systemPrompt 系统提示词
     * @param model 聊天模型
     * @return ReActAgent 实例
     */
    public static ReActAgent createSimpleAgent(String name, String systemPrompt, Model model) {
        return createAgent(AgentConfig.builder()
                .name(name)
                .systemPrompt(systemPrompt)
                .model(model)
                .build());
    }
}
