/*
 * Copyright 2024-2026 Luoshen Team
 */
package io.luoshen.core.manager;

import io.agentscope.core.session.InMemorySession;
import io.agentscope.core.session.Session;
import io.agentscope.core.state.SessionKey;
import io.agentscope.core.state.SimpleSessionKey;
import lombok.extern.slf4j.Slf4j;

import java.util.Optional;
import java.util.Set;

/**
 * 会话管理器
 * 
 * 管理用户会话的持久化和恢复
 * 基于 AgentScope 的 Session 接口
 */
@Slf4j
public class SessionManager {

    private final Session session;

    /**
     * 创建会话管理器（使用内存存储）
     */
    public SessionManager() {
        this.session = new InMemorySession();
        log.info("SessionManager initialized with InMemorySession");
    }

    /**
     * 创建会话管理器（使用指定存储）
     *
     * @param session Session 实例
     */
    public SessionManager(Session session) {
        this.session = session;
        log.info("SessionManager initialized");
    }

    /**
     * 创建新会话
     *
     * @param sessionId 会话 ID
     * @return SessionKey
     */
    public SessionKey createSession(String sessionId) {
        SessionKey key = SimpleSessionKey.of(sessionId);
        log.info("Session created: {}", sessionId);
        return key;
    }

    /**
     * 检查会话是否存在
     *
     * @param sessionId 会话 ID
     * @return 是否存在
     */
    public boolean exists(String sessionId) {
        return session.exists(SimpleSessionKey.of(sessionId));
    }

    /**
     * 删除会话
     *
     * @param sessionId 会话 ID
     */
    public void deleteSession(String sessionId) {
        session.delete(SimpleSessionKey.of(sessionId));
        log.info("Session deleted: {}", sessionId);
    }

    /**
     * 列出所有会话
     *
     * @return 会话 Key 集合
     */
    public Set<SessionKey> listSessions() {
        return session.listSessionKeys();
    }

    /**
     * 获取底层 Session 实例
     *
     * @return Session 实例
     */
    public Session getSession() {
        return session;
    }
}
