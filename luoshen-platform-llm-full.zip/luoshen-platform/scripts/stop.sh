#!/bin/bash
# 洛神平台一键停止脚本

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${YELLOW}停止洛神平台服务...${NC}"

# 停止后端 (9090)
if lsof -ti:9090 > /dev/null 2>&1; then
    lsof -ti:9090 | xargs kill -9 2>/dev/null || true
    echo -e "${GREEN}✓ 后端已停止 (端口 9090)${NC}"
else
    echo -e "${YELLOW}后端未运行${NC}"
fi

# 停止前端 (5173)
if lsof -ti:5173 > /dev/null 2>&1; then
    lsof -ti:5173 | xargs kill -9 2>/dev/null || true
    echo -e "${GREEN}✓ 前端已停止 (端口 5173)${NC}"
else
    echo -e "${YELLOW}前端未运行${NC}"
fi

# 停止 Leader Agent (8080)
if lsof -ti:8080 > /dev/null 2>&1; then
    lsof -ti:8080 | xargs kill -9 2>/dev/null || true
    echo -e "${GREEN}✓ Leader Agent 已停止 (端口 8080)${NC}"
fi

echo -e "${GREEN}所有服务已停止${NC}"
