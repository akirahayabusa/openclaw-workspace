@echo off
chcp 65001 >nul
REM 洛神平台 Windows 一键启动脚本
REM 用法: start.bat [选项]
REM 选项: --backend-only | --frontend-only | --demo

echo ================================
echo   洛神平台启动脚本 (Windows)
echo ================================
echo.

REM 切换到项目根目录
cd /d "%~dp0.."
set PROJECT_DIR=%cd%

REM 检查命令是否存在
where java >nul 2>&1
if %errorlevel% neq 0 (
    echo [错误] 未找到 java 命令，请先安装 JDK 17+
    pause
    exit /b 1
)

where mvn >nul 2>&1
if %errorlevel% neq 0 (
    echo [错误] 未找到 mvn 命令，请先安装 Maven
    pause
    exit /b 1
)

REM 解析参数
set "MODE=%~1"
if "%MODE%"=="" set "MODE=all"

REM 启动后端
if "%MODE%"=="all" goto :start_backend
if "%MODE%"=="--backend-only" goto :start_backend
if "%MODE%"=="--demo" goto :start_backend
goto :check_frontend

:start_backend
echo [1/4] 检查后端环境...
java -version 2>&1 | findstr /i "version" >nul
if %errorlevel% neq 0 (
    echo [错误] Java 版本检查失败
    pause
    exit /b 1
)

echo [2/4] 检查端口 9090...
netstat -ano | findstr ":9090" | findstr "LISTENING" >nul
if %errorlevel% equ 0 (
    echo [警告] 端口 9090 已被占用
    set /p choice="是否终止占用进程？(y/n): "
    if /i "%choice%"=="y" (
        for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":9090" ^| findstr "LISTENING"') do (
            taskkill /f /pid %%a >nul 2>&1
        )
        echo [成功] 已终止占用端口 9090 的进程
    ) else (
        echo [错误] 无法启动，端口被占用
        pause
        exit /b 1
    )
)

echo [3/4] 编译后端...
cd /d "%PROJECT_DIR%\luoshen-admin"
call mvn compile -DskipTests -q
if %errorlevel% neq 0 (
    echo [错误] 后端编译失败
    pause
    exit /b 1
)

echo [4/4] 启动后端服务 (端口 9090)...
start "Luoshen Backend" cmd /c "mvn spring-boot:run -DskipTests"
echo [启动中] 等待后端启动...

REM 等待后端启动
set /a count=0
:wait_backend
timeout /t 1 >nul
set /a count+=1
curl -s http://localhost:9090/api/dashboard/health >nul 2>&1
if %errorlevel% equ 0 (
    echo [成功] 后端启动成功
    goto :check_frontend
)
if %count% lss 30 goto :wait_backend
echo [错误] 后端启动超时
pause
exit /b 1

:check_frontend
if "%MODE%"=="--backend-only" goto :show_info

REM 启动前端
echo.
echo [1/3] 检查前端环境...
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo [错误] 未找到 node 命令，请先安装 Node.js 18+
    pause
    exit /b 1
)

echo [2/3] 检查端口 5173...
netstat -ano | findstr ":5173" | findstr "LISTENING" >nul
if %errorlevel% equ 0 (
    echo [警告] 端口 5173 已被占用
    set /p choice="是否终止占用进程？(y/n): "
    if /i "%choice%"=="y" (
        for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":5173" ^| findstr "LISTENING"') do (
            taskkill /f /pid %%a >nul 2>&1
        )
        echo [成功] 已终止占用端口 5173 的进程
    )
)

echo [3/3] 启动前端服务 (端口 5173)...
cd /d "%PROJECT_DIR%\luoshen-web"

REM 检查 node_modules
if not exist "node_modules" (
    echo [安装] 正在安装依赖...
    call npm install --silent
)

start "Luoshen Frontend" cmd /c "npm run dev"
echo [成功] 前端启动成功

REM 加载示例数据
if "%MODE%"=="--demo" (
    echo.
    echo [加载] 正在加载示例数据...
    timeout /t 3 >nul
    
    curl -s -X POST http://localhost:9090/api/agents ^
        -H "Content-Type: application/json" ^
        -d "{\"agentId\":\"demo-device-agent\",\"name\":\"设备管理Agent\",\"type\":\"CORE\",\"parentAgentId\":\"luoshen-leader\",\"systemPrompt\":\"你是设备管理专家\",\"modelName\":\"qwen-plus\",\"enabled\":true}" >nul 2>&1
    
    curl -s -X POST http://localhost:9090/api/skills ^
        -H "Content-Type: application/json" ^
        -d "{\"skillId\":\"demo-code-review\",\"name\":\"代码审查\",\"description\":\"代码质量审查\",\"content\":\"# 代码审查技能\",\"enabled\":true}" >nul 2>&1
    
    echo [成功] 示例数据加载完成
)

:show_info
echo.
echo ================================
echo   启动完成！
echo ================================
echo.
echo   前端界面: http://localhost:5173
echo   后端 API: http://localhost:9090
echo   健康检查: http://localhost:9090/api/dashboard/health
echo   H2 控制台: http://localhost:9090/h2-console
echo.
echo   提示: 配置 DASHSCOPE_API_KEY 后可测试对话功能
echo         set DASHSCOPE_API_KEY=your-api-key
echo.
echo ================================
echo.
echo 按任意键关闭此窗口（服务将继续运行）...
pause >nul
