#!/bin/bash
# 洛神平台一键启动脚本
# 用法: ./start.sh [选项]
# 选项: --backend-only | --frontend-only | --demo

set -e

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}================================${NC}"
echo -e "${GREEN}  洛神平台启动脚本${NC}"
echo -e "${GREEN}================================${NC}"

# 切换到项目根目录
cd "$(dirname "$0")/.."
PROJECT_DIR=$(pwd)

# 检查命令是否存在
check_command() {
    if ! command -v $1 &> /dev/null; then
        echo -e "${RED}错误: 未找到 $1 命令${NC}"
        echo "请先安装 $1"
        exit 1
    fi
}

# 检查端口是否被占用
check_port() {
    if lsof -Pi :$1 -sTCP:LISTEN -t >/dev/null 2>&1; then
        echo -e "${YELLOW}警告: 端口 $1 已被占用${NC}"
        read -p "是否终止占用进程？(y/n): " choice
        if [[ $choice == "y" || $choice == "Y" ]]; then
            lsof -ti:$1 | xargs kill -9 2>/dev/null || true
            echo -e "${GREEN}已终止占用端口 $1 的进程${NC}"
        else
            echo -e "${RED}无法启动，端口被占用${NC}"
            exit 1
        fi
    fi
}

# 启动后端
start_backend() {
    echo -e "${GREEN}[1/4] 检查后端环境...${NC}"
    check_command java
    check_command mvn
    
    echo -e "${GREEN}[2/4] 检查端口...${NC}"
    check_port 9090
    
    echo -e "${GREEN}[3/4] 编译后端...${NC}"
    cd $PROJECT_DIR/luoshen-admin
    mvn compile -DskipTests -q
    
    echo -e "${GREEN}[4/4] 启动后端服务 (端口 9090)...${NC}"
    mvn spring-boot:run -DskipTests -q &
    BACKEND_PID=$!
    
    # 等待服务启动
    echo -n "等待后端启动"
    for i in {1..30}; do
        if curl -s http://localhost:9090/api/dashboard/health > /dev/null 2>&1; then
            echo -e "\n${GREEN}✓ 后端启动成功${NC}"
            return 0
        fi
        echo -n "."
        sleep 1
    done
    
    echo -e "\n${RED}✗ 后端启动超时${NC}"
    return 1
}

# 启动前端
start_frontend() {
    echo -e "${GREEN}[1/3] 检查前端环境...${NC}"
    check_command node
    check_command npm
    
    echo -e "${GREEN}[2/3] 检查端口...${NC}"
    check_port 5173
    
    echo -e "${GREEN}[3/3] 启动前端服务 (端口 5173)...${NC}"
    cd $PROJECT_DIR/luoshen-web
    
    # 检查 node_modules
    if [ ! -d "node_modules" ]; then
        echo "安装依赖..."
        npm install --silent
    fi
    
    npm run dev -- --host > /dev/null 2>&1 &
    FRONTEND_PID=$!
    
    # 等待服务启动
    echo -n "等待前端启动"
    for i in {1..15}; do
        if curl -s http://localhost:5173 > /dev/null 2>&1; then
            echo -e "\n${GREEN}✓ 前端启动成功${NC}"
            return 0
        fi
        echo -n "."
        sleep 1
    done
    
    echo -e "\n${RED}✗ 前端启动超时${NC}"
    return 1
}

# 加载示例数据
load_demo_data() {
    echo -e "${GREEN}加载示例数据...${NC}"
    
    # 等待后端启动
    sleep 3
    
    # 创建示例 Agent
    curl -s -X POST http://localhost:9090/api/agents \
        -H "Content-Type: application/json" \
        -d '{
            "agentId": "demo-device-agent",
            "name": "设备管理Agent",
            "description": "负责设备状态监控和维护",
            "type": "CORE",
            "parentAgentId": "luoshen-leader",
            "systemPrompt": "你是设备管理专家，负责设备状态监控、故障诊断、维护计划。",
            "modelName": "qwen-plus",
            "enabled": true
        }' > /dev/null 2>&1 || true
    
    curl -s -X POST http://localhost:9090/api/agents \
        -H "Content-Type: application/json" \
        -d '{
            "agentId": "demo-quality-agent",
            "name": "质量检测Agent",
            "description": "负责产品质量检测",
            "type": "SUB",
            "parentAgentId": "demo-device-agent",
            "systemPrompt": "你是质量检测专家，负责产品质检、异常识别、质量报告生成。",
            "modelName": "qwen-plus",
            "enabled": true
        }' > /dev/null 2>&1 || true
    
    # 创建示例 Skill
    curl -s -X POST http://localhost:9090/api/skills \
        -H "Content-Type: application/json" \
        -d '{
            "skillId": "demo-code-review",
            "name": "代码审查",
            "description": "代码质量审查和优化建议",
            "content": "# 代码审查技能\n\n你是代码审查专家，负责：\n1. 代码质量检查\n2. 安全漏洞识别\n3. 性能优化建议",
            "enabled": true
        }' > /dev/null 2>&1 || true
    
    echo -e "${GREEN}✓ 示例数据加载完成${NC}"
}

# 显示访问信息
show_info() {
    echo ""
    echo -e "${GREEN}================================${NC}"
    echo -e "${GREEN}  启动完成！${NC}"
    echo -e "${GREEN}================================${NC}"
    echo ""
    echo -e "  前端界面: ${YELLOW}http://localhost:5173${NC}"
    echo -e "  后端 API: ${YELLOW}http://localhost:9090${NC}"
    echo -e "  健康检查: ${YELLOW}http://localhost:9090/api/dashboard/health${NC}"
    echo -e "  H2 控制台: ${YELLOW}http://localhost:9090/h2-console${NC}"
    echo ""
    echo -e "  ${YELLOW}提示: 配置 DASHSCOPE_API_KEY 后可测试对话功能${NC}"
    echo -e "  ${YELLOW}      export DASHSCOPE_API_KEY=your-api-key${NC}"
    echo ""
    echo -e "${GREEN}================================${NC}"
}

# 停止服务
stop_services() {
    echo -e "${YELLOW}停止服务...${NC}"
    
    # 停止后端
    if lsof -ti:9090 > /dev/null 2>&1; then
        lsof -ti:9090 | xargs kill -9 2>/dev/null || true
        echo -e "${GREEN}✓ 后端已停止${NC}"
    fi
    
    # 停止前端
    if lsof -ti:5173 > /dev/null 2>&1; then
        lsof -ti:5173 | xargs kill -9 2>/dev/null || true
        echo -e "${GREEN}✓ 前端已停止${NC}"
    fi
}

# 主流程
main() {
    case "${1:-}" in
        --stop)
            stop_services
            exit 0
            ;;
        --backend-only)
            start_backend
            ;;
        --frontend-only)
            start_frontend
            ;;
        --demo)
            start_backend
            start_frontend
            load_demo_data
            show_info
            ;;
        *)
            start_backend
            start_frontend
            show_info
            ;;
    esac
}

main "$@"
