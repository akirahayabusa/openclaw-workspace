@echo off
chcp 65001 >nul
REM 洛神平台 Windows 停止脚本

echo ================================
echo   停止洛神平台服务
echo ================================
echo.

REM 停止后端 (9090)
echo [检查] 后端服务 (端口 9090)...
netstat -ano | findstr ":9090" | findstr "LISTENING" >nul
if %errorlevel% equ 0 (
    for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":9090" ^| findstr "LISTENING"') do (
        taskkill /f /pid %%a >nul 2>&1
    )
    echo [成功] 后端已停止
) else (
    echo [跳过] 后端未运行
)

REM 停止前端 (5173)
echo [检查] 前端服务 (端口 5173)...
netstat -ano | findstr ":5173" | findstr "LISTENING" >nul
if %errorlevel% equ 0 (
    for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":5173" ^| findstr "LISTENING"') do (
        taskkill /f /pid %%a >nul 2>&1
    )
    echo [成功] 前端已停止
) else (
    echo [跳过] 前端未运行
)

REM 停止 Leader Agent (8080)
echo [检查] Leader Agent (端口 8080)...
netstat -ano | findstr ":8080" | findstr "LISTENING" >nul
if %errorlevel% equ 0 (
    for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":8080" ^| findstr "LISTENING"') do (
        taskkill /f /pid %%a >nul 2>&1
    )
    echo [成功] Leader Agent 已停止
) else (
    echo [跳过] Leader Agent 未运行
)

echo.
echo [完成] 所有服务已停止
echo.
pause
