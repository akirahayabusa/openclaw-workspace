# 洛神平台 (Luoshen Platform)

基于 AgentScope-Java 的企业级多智能体协作平台，支持 **ATOA 协议**（Agent-To-Agent）实现三级智能体协作。

## ✨ 核心特性

- **动态配置管理** - Agent/Skill/MCP 配置热更新，立即生效
- **ATOA 协议** - Leader → Core → Sub 三级智能体协作
- **多 LLM 支持** - 阿里云灵积、火山方舟、OpenAI
- **会话持久化** - JsonSession 文件系统存储
- **流式对话** - SSE 实时响应
- **Web 管理界面** - Vue 3 + Element Plus

## 📦 项目结构

```
luoshen-platform/
├── luoshen-core/              # 核心业务逻辑
│   ├── factory/               # Agent 工厂
│   ├── loader/                # 技能加载器
│   └── manager/               # MCP/Session 管理器
│
├── luoshen-admin/             # 管理后台 + 运行时
│   ├── controller/            # REST API
│   ├── service/               # 业务服务
│   ├── runtime/               # 🔥 运行时管理
│   │   ├── AgentRuntimeManager    # Agent 实例缓存
│   │   ├── SkillRuntimeService    # 技能动态加载
│   │   ├── McpRuntimeService      # MCP 动态连接
│   │   ├── MemoryPersistenceService  # 会话持久化
│   │   └── AgentCoordinator       # ATOA 协调器
│   ├── llm/                   # 多 LLM 支持
│   └── exception/             # 异常处理
│
├── luoshen-leader/            # Leader Agent 独立进程
└── luoshen-web/               # Vue 3 前端
    └── src/views/             # 管理页面
        ├── Dashboard.vue      # 仪表盘
        ├── AgentList.vue      # Agent 管理
        ├── SkillList.vue      # Skill 管理
        ├── McpList.vue        # MCP 配置
        └── ChatView.vue       # 对话测试
```

## 🏗️ 三级 Agent 架构（ATOA 协议）

```
┌─────────────────────────────────────────────────────────┐
│                    Leader/Master Agent                   │
│                    (主控智能体，唯一)                      │
│                                                          │
│  职责：接收用户请求，分发任务给 Core Agent，汇总结果        │
└───────────────────────────┬─────────────────────────────┘
                            │ subAgent 工具调用
              ┌─────────────┼─────────────┐
              ▼             ▼             ▼
      ┌───────────┐  ┌───────────┐  ┌───────────┐
      │ 设备 Agent │  │ 人员 Agent │  │ 物料 Agent │
      │  (Core)   │  │  (Core)   │  │  (Core)   │
      └─────┬─────┘  └─────┬─────┘  └─────┬─────┘
            │              │              │
     ┌──────┴──────┐       │       ┌──────┴──────┐
     ▼             ▼       ▼       ▼             ▼
┌────────┐   ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐
│质量Agent│   │物料Agent│ │考勤Agent│ │库存Agent│ │采购Agent│
│ (Sub)  │   │ (Sub)  │ │ (Sub)  │ │ (Sub)  │ │ (Sub)  │
└────────┘   └────────┘ └────────┘ └────────┘ └────────┘
```

### Agent 类型说明

| 类型 | 数量 | 父级 | 职责 |
|------|------|------|------|
| **LEADER** | 1 | 无 | 主控，接收用户请求，调度 Core Agent |
| **CORE** | 多个 | LEADER | 领域专家，处理特定领域任务 |
| **SUB** | 多个 | CORE | 子任务执行者，完成具体操作 |

## 🔧 运行时管理

### 配置热更新流程

```
1. 管理平台修改 Agent/Skill/MCP 配置
        ↓
2. AgentConfigService.update() 调用
        ↓
3. agentRuntimeManager.invalidateAgent(agentId)
        ↓
4. 下次对话时重新创建 Agent（新配置生效）
```

### Agent 创建流程

```java
AgentRuntimeManager.getOrCreateAgent(agentId)
    │
    ├─→ 从数据库加载配置
    │
    ├─→ 创建 LLM 模型（支持多提供商）
    │
    ├─→ 创建 Toolkit
    │     ├─→ 加载技能（SkillRuntimeService）
    │     ├─→ 连接 MCP（McpRuntimeService）
    │     └─→ 注册子 Agent（ATOA 协议）
    │
    └─→ 创建 ReActAgent 实例
```

## 🚀 快速开始

### 环境要求

- Java 17+
- Maven 3.8+
- Node.js 18+ (前端开发)

### 配置 API Key

```bash
# 阿里云灵积
export DASHSCOPE_API_KEY="your-api-key"

# 火山方舟
export VOLCENGINE_API_KEY="your-api-key"

# OpenAI
export OPENAI_API_KEY="your-api-key"
```

### 启动后端

```bash
# 编译
mvn clean install -DskipTests

# 启动管理后台（端口 9090）
cd luoshen-admin
mvn spring-boot:run

# 启动 Leader Agent（可选，端口 8080）
cd luoshen-leader
mvn spring-boot:run
```

### 启动前端

```bash
cd luoshen-web
npm install
npm run dev
# 访问 http://localhost:5173
```

## 📡 API 端点

### Agent 管理

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/agents` | 列出所有 Agent |
| GET | `/api/agents/tree` | 获取 Agent 树 |
| POST | `/api/agents` | 创建 Agent |
| PUT | `/api/agents/{id}` | 更新 Agent（清理缓存） |
| DELETE | `/api/agents/{id}` | 删除 Agent |

### 对话

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/api/chat/send` | 同步对话 |
| POST | `/api/chat/stream` | SSE 流式对话 |
| GET | `/api/chat/history/{sessionId}` | 获取历史 |
| DELETE | `/api/chat/session/{sessionId}` | 清除会话 |

### Skill/MCP 管理

- `/api/skills` - Skill CRUD
- `/api/mcp` - MCP 配置

## 🎯 多 LLM 支持

### 模型名称格式

| 格式 | 提供商 | 示例 |
|------|--------|------|
| `qwen-plus` | 阿里云灵积 | `qwen-max`, `qwen-turbo` |
| `volcengine:/ep-xxx` | 火山方舟 | `volcengine:/ep-20240301` |
| `openai:/gpt-4` | OpenAI | `openai:/gpt-4o-mini` |

## 📁 数据存储

```
data/
├── luoshen.mv.db      # H2 数据库
├── skills/            # 技能文件（Markdown）
│   ├── code-review.md
│   └── data-analysis.md
└── sessions/          # 会话持久化
    ├── session-1.json
    └── session-2.json
```

## 🔌 配置文件

`application.yml`:

```yaml
# 洛神平台配置
luoshen:
  skills:
    path: ./data/skills
  sessions:
    path: ./data/sessions

# LLM 提供商
llm:
  dashscope:
    api-key: ${DASHSCOPE_API_KEY:}
  volcengine:
    api-key: ${VOLCENGINE_API_KEY:}
  openai:
    api-key: ${OPENAI_API_KEY:}
```

## 🛠️ 开发计划

- [x] 项目初始化
- [x] luoshen-core 核心模块
- [x] luoshen-admin 管理后台
- [x] 运行时管理（缓存、热更新）
- [x] ATOA 协议支持
- [x] 多 LLM 支持
- [x] luoshen-web 前端界面
- [x] 会话持久化
- [ ] MCP 完整集成
- [ ] Docker 容器化
- [ ] 生产环境部署

## 📄 License

Apache 2.0
