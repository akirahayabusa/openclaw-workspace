/*
 * Copyright 2024-2026 Luoshen Team
 */
package io.luoshen.leader;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Leader Agent 启动类
 * 
 * 主控智能体，负责任务分发和结果汇总
 */
@SpringBootApplication
public class LuoshenLeaderApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(LuoshenLeaderApplication.class, args);
    }
}
