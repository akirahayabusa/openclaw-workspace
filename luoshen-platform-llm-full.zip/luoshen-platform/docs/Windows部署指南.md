# 洛神平台 Windows 部署指南

> 版本: 1.0.0 | 更新日期: 2026-03-31

---

## 1. 环境要求

### 1.1 软件要求

| 软件 | 版本要求 | 下载地址 |
|------|---------|---------|
| **JDK** | 17 或更高 | https://adoptium.net/ |
| **Maven** | 3.8 或更高 | https://maven.apache.org/download.cgi |
| **Node.js** | 18 或更高 | https://nodejs.org/ |
| **Git** | 2.0 或更高 | https://git-scm.com/download/win |

### 1.2 硬件要求

| 配置 | 最低要求 | 推荐配置 |
|------|---------|---------|
| CPU | 2 核 | 4 核+ |
| 内存 | 4 GB | 8 GB+ |
| 磁盘 | 20 GB | 50 GB+ |

---

## 2. 安装步骤

### 2.1 安装 JDK 17

1. **下载 JDK**
   - 访问 https://adoptium.net/
   - 选择 Temurin 17 (LTS)
   - 下载 Windows x64 安装包

2. **安装 JDK**
   ```
   双击安装包，按提示完成安装
   ```

3. **配置环境变量**
   
   **方式1：通过系统设置**
   - 右键「此电脑」→「属性」→「高级系统设置」
   - 点击「环境变量」
   - 新建系统变量：
     - 变量名：`JAVA_HOME`
     - 变量值：`C:\Program Files\Eclipse Adoptium\jdk-17.x.x`（实际安装路径）
   - 编辑 `Path` 变量，添加：
     - `%JAVA_HOME%\bin`

   **方式2：通过命令行（管理员）**
   ```cmd
   setx JAVA_HOME "C:\Program Files\Eclipse Adoptium\jdk-17.0.8.101-hotspot" /M
   setx Path "%Path%;%JAVA_HOME%\bin" /M
   ```

4. **验证安装**
   ```cmd
   java -version
   ```
   应输出类似：`openjdk version "17.0.8"`

### 2.2 安装 Maven

1. **下载 Maven**
   - 访问 https://maven.apache.org/download.cgi
   - 下载 Binary zip archive

2. **解压到指定目录**
   ```
   解压到 C:\Program Files\Apache\maven
   ```

3. **配置环境变量**
   - 新建系统变量：
     - 变量名：`MAVEN_HOME`
     - 变量值：`C:\Program Files\Apache\maven`
   - 编辑 `Path` 变量，添加：
     - `%MAVEN_HOME%\bin`

4. **验证安装**
   ```cmd
   mvn -version
   ```

### 2.3 安装 Node.js

1. **下载 Node.js**
   - 访问 https://nodejs.org/
   - 下载 LTS 版本（18.x 或更高）

2. **安装 Node.js**
   ```
   双击安装包，按提示完成安装（会自动配置环境变量）
   ```

3. **验证安装**
   ```cmd
   node -version
   npm -version
   ```

### 2.4 安装 Git

1. **下载 Git**
   - 访问 https://git-scm.com/download/win
   - 下载 Windows 安装包

2. **安装 Git**
   ```
   双击安装包，使用默认选项
   ```

3. **验证安装**
   ```cmd
   git -version
   ```

---

## 3. 获取代码

### 3.1 克隆仓库

```cmd
# 创建项目目录
mkdir C:\projects
cd C:\projects

# 克隆代码
git clone https://github.com/akirahayabusa/openclaw-workspace.git
cd openclaw-workspace\luoshen-platform
```

### 3.2 初始化子模块

```cmd
git submodule update --init --recursive
```

---

## 4. 配置

### 4.1 配置 LLM API Key

**方式1：系统环境变量（推荐）**

1. 右键「此电脑」→「属性」→「高级系统设置」
2. 点击「环境变量」
3. 新建用户变量：
   - 变量名：`DASHSCOPE_API_KEY`
   - 变量值：`your-api-key`

**方式2：命令行临时设置**
```cmd
set DASHSCOPE_API_KEY=your-api-key
```

**方式3：配置文件**

编辑 `luoshen-admin\src\main\resources\application.yml`:
```yaml
llm:
  dashscope:
    api-key: your-api-key
```

### 4.2 验证配置

```cmd
echo %DASHSCOPE_API_KEY%
```

---

## 5. 启动服务

### 5.1 使用启动脚本（推荐）

```cmd
cd C:\projects\openclaw-workspace\luoshen-platform\scripts
start.bat
```

**可选参数：**
- `start.bat` - 启动后端和前端
- `start.bat --backend-only` - 仅启动后端
- `start.bat --frontend-only` - 仅启动前端
- `start.bat --demo` - 启动并加载示例数据

### 5.2 手动启动

**启动后端：**
```cmd
cd luoshen-admin
mvn spring-boot:run
```

**启动前端（新窗口）：**
```cmd
cd luoshen-web
npm install
npm run dev
```

### 5.3 停止服务

**方式1：使用停止脚本**
```cmd
cd scripts
stop.bat
```

**方式2：手动停止**
- 在运行窗口按 `Ctrl+C`
- 或关闭命令行窗口

---

## 6. 访问服务

启动成功后，可通过以下地址访问：

| 服务 | 地址 |
|------|------|
| 前端界面 | http://localhost:5173 |
| 后端 API | http://localhost:9090 |
| 健康检查 | http://localhost:9090/api/dashboard/health |
| H2 控制台 | http://localhost:9090/h2-console |

### 6.1 H2 数据库连接

| 项目 | 值 |
|------|------|
| JDBC URL | `jdbc:h2:file:./data/luoshen` |
| 用户名 | `sa` |
| 密码 | （空）|

---

## 7. 常见问题

### 7.1 端口被占用

**问题：** 启动时提示端口 9090 或 5173 被占用

**解决：**
```cmd
# 查看占用端口的进程
netstat -ano | findstr :9090

# 终止进程（替换 PID）
taskkill /f /pid <PID>
```

### 7.2 Java 版本不正确

**问题：** 启动时报错 `Unsupported class file major version 61`

**解决：** 确保安装了 JDK 17+
```cmd
java -version
```

### 7.3 Maven 编译失败

**问题：** `mvn compile` 失败

**解决：**
```cmd
# 清理后重新编译
mvn clean compile -DskipTests

# 如果仍失败，删除本地缓存
rd /s /q %USERPROFILE%\.m2\repository\io\agentscope
mvn compile -DskipTests
```

### 7.4 npm install 失败

**问题：** 前端依赖安装失败

**解决：**
```cmd
# 设置国内镜像
npm config set registry https://registry.npmmirror.com

# 清理缓存
npm cache clean --force

# 重新安装
npm install
```

### 7.5 对话无响应

**问题：** 对话测试时无响应或报错

**解决：**
1. 检查 API Key 是否配置
   ```cmd
   echo %DASHSCOPE_API_KEY%
   ```
2. 检查 Agent 是否启用
3. 查看后端日志是否有错误

---

## 8. 防火墙配置

如果需要从其他机器访问，需要配置 Windows 防火墙：

### 8.1 允许端口

**方式1：通过控制面板**
1. 控制面板 → Windows Defender 防火墙 → 高级设置
2. 入站规则 → 新建规则
3. 选择「端口」→「TCP」→ 特定端口：9090, 5173
4. 选择「允许连接」
5. 应用到所有配置文件

**方式2：通过命令行（管理员）**
```cmd
netsh advfirewall firewall add rule name="Luoshen Backend" dir=in action=allow protocol=TCP localport=9090
netsh advfirewall firewall add rule name="Luoshen Frontend" dir=in action=allow protocol=TCP localport=5173
```

---

## 9. Windows 服务注册（可选）

将后端注册为 Windows 服务，实现开机自启动。

### 9.1 使用 NSSM

1. **下载 NSSM**
   - https://nssm.cc/download
   - 解压到 `C:\Program Files\nssm`

2. **打包后端**
   ```cmd
   cd luoshen-admin
   mvn clean package -DskipTests
   ```

3. **安装服务**
   ```cmd
   nssm install LuoshenAdmin "C:\Program Files\Java\jdk-17\bin\java.exe" "-jar C:\projects\openclaw-workspace\luoshen-platform\luoshen-admin\target\luoshen-admin-1.0.0-SNAPSHOT.jar"
   
   # 设置环境变量
   nssm set LuoshenAdmin AppEnvironmentExtra DASHSCOPE_API_KEY=your-api-key
   
   # 启动服务
   nssm start LuoshenAdmin
   ```

4. **管理服务**
   ```cmd
   nssm start LuoshenAdmin    # 启动
   nssm stop LuoshenAdmin     # 停止
   nssm restart LuoshenAdmin  # 重启
   nssm remove LuoshenAdmin   # 删除
   ```

---

## 10. 快速启动指南

**最简启动步骤：**

```cmd
# 1. 克隆代码
git clone https://github.com/akirahayabusa/openclaw-workspace.git
cd openclaw-workspace\luoshen-platform

# 2. 设置 API Key
set DASHSCOPE_API_KEY=your-api-key

# 3. 启动服务
cd scripts
start.bat

# 4. 访问
# 前端: http://localhost:5173
# 后端: http://localhost:9090
```

---

## 附录：目录结构

```
C:\projects\openclaw-workspace\
└── luoshen-platform\
    ├── luoshen-core\           # 核心模块
    ├── luoshen-admin\          # 后端服务
    ├── luoshen-leader\         # Leader Agent
    ├── luoshen-web\            # 前端界面
    ├── scripts\
    │   ├── start.bat           # Windows 启动脚本
    │   ├── stop.bat            # Windows 停止脚本
    │   ├── start.sh            # Linux/Mac 启动脚本
    │   └── stop.sh             # Linux/Mac 停止脚本
    └── docs\                   # 文档
```

---

*Windows 部署指南 - 洛神平台开发团队*
