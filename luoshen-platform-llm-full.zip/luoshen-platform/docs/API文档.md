# 洛神平台 API 文档

> 版本: 1.0.0 | 更新日期: 2026-03-31
> 
> 基础 URL: `http://localhost:9090`

---

## 目录

1. [概述](#1-概述)
2. [通用说明](#2-通用说明)
3. [Agent 管理接口](#3-agent-管理接口)
4. [Skill 管理接口](#4-skill-管理接口)
5. [MCP 管理接口](#5-mcp-管理接口)
6. [对话接口](#6-对话接口)
7. [仪表盘接口](#7-仪表盘接口)
8. [错误码](#8-错误码)
9. [数据模型](#9-数据模型)

---

## 1. 概述

### 1.1 简介

洛神平台提供 RESTful API，用于管理 Agent、Skill、MCP 配置以及进行对话交互。

### 1.2 基础信息

| 项目 | 说明 |
|------|------|
| 协议 | HTTP/HTTPS |
| 数据格式 | JSON |
| 字符编码 | UTF-8 |
| 基础 URL | `http://localhost:9090` |

### 1.3 接口列表

| 模块 | 路径前缀 | 说明 |
|------|---------|------|
| Agent | `/api/agents` | 智能体管理 |
| Skill | `/api/skills` | 技能管理 |
| MCP | `/api/mcp` | MCP 配置管理 |
| Chat | `/api/chat` | 对话交互 |
| Dashboard | `/api/dashboard` | 系统监控 |

---

## 2. 通用说明

### 2.1 请求头

```http
Content-Type: application/json
Accept: application/json
```

### 2.2 响应格式

**成功响应:**

```json
{
  "id": 1,
  "agentId": "example-agent",
  "name": "示例Agent",
  ...
}
```

**错误响应:**

```json
{
  "timestamp": "2026-03-31T10:30:00.000+08:00",
  "status": 404,
  "error": "Not Found",
  "message": "Agent 不存在: xxx",
  "path": "/api/agents/xxx"
}
```

### 2.3 HTTP 状态码

| 状态码 | 说明 |
|--------|------|
| 200 | 成功 |
| 201 | 创建成功 |
| 204 | 删除成功（无返回内容）|
| 400 | 请求参数错误 |
| 404 | 资源不存在 |
| 500 | 服务器内部错误 |

---

## 3. Agent 管理接口

### 3.1 获取所有 Agent

**请求:**

```http
GET /api/agents
```

**响应:**

```json
[
  {
    "id": 1,
    "agentId": "luoshen-leader",
    "name": "洛神总控",
    "description": "主控智能体",
    "type": "LEADER",
    "parentAgentId": null,
    "systemPrompt": "你是洛神平台的主控智能体",
    "modelName": "qwen-plus",
    "toolsJson": null,
    "skillsJson": null,
    "mcpServersJson": null,
    "subAgentsJson": null,
    "enabled": true,
    "createdAt": "2026-03-31T08:56:57.591692",
    "updatedAt": "2026-03-31T08:56:57.591692"
  }
]
```

### 3.2 获取单个 Agent

**请求:**

```http
GET /api/agents/{agentId}
```

**参数:**

| 参数 | 位置 | 类型 | 必填 | 说明 |
|------|------|------|------|------|
| agentId | path | string | 是 | Agent 唯一标识 |

**响应:**

```json
{
  "id": 1,
  "agentId": "luoshen-leader",
  "name": "洛神总控",
  "description": "主控智能体",
  "type": "LEADER",
  "parentAgentId": null,
  "systemPrompt": "你是洛神平台的主控智能体",
  "modelName": "qwen-plus",
  "toolsJson": null,
  "skillsJson": null,
  "mcpServersJson": null,
  "subAgentsJson": null,
  "enabled": true,
  "createdAt": "2026-03-31T08:56:57.591692",
  "updatedAt": "2026-03-31T08:56:57.591692"
}
```

### 3.3 创建 Agent

**请求:**

```http
POST /api/agents
Content-Type: application/json

{
  "agentId": "device-agent",
  "name": "设备管理Agent",
  "description": "负责设备状态监控和维护",
  "type": "CORE",
  "parentAgentId": "luoshen-leader",
  "systemPrompt": "你是设备管理专家，负责设备状态监控、故障诊断、维护计划。",
  "modelName": "qwen-plus",
  "toolsJson": null,
  "skillsJson": "[\"device-analysis\"]",
  "mcpServersJson": null,
  "subAgentsJson": "[\"quality-agent\", \"maintenance-agent\"]",
  "enabled": true
}
```

**请求体字段:**

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| agentId | string | 是 | 唯一标识，建议使用 kebab-case |
| name | string | 是 | 显示名称 |
| description | string | 否 | 功能描述 |
| type | string | 是 | 类型：LEADER / CORE / SUB |
| parentAgentId | string | 条件 | 父 Agent ID（CORE/SUB 必填）|
| systemPrompt | string | 否 | 系统提示词 |
| modelName | string | 否 | LLM 模型名称，默认 qwen-plus |
| toolsJson | string | 否 | 工具列表 JSON |
| skillsJson | string | 否 | 技能 ID 列表 JSON |
| mcpServersJson | string | 否 | MCP 服务器 ID 列表 JSON |
| subAgentsJson | string | 否 | 子 Agent ID 列表 JSON |
| enabled | boolean | 否 | 是否启用，默认 true |

**响应:** 返回创建的 Agent 对象

### 3.4 更新 Agent

**请求:**

```http
PUT /api/agents/{agentId}
Content-Type: application/json

{
  "name": "设备管理Agent（更新）",
  "description": "负责设备状态监控、维护和诊断",
  "enabled": true
}
```

**⚠️ 注意:** 更新配置后会自动清理缓存，下次对话立即生效。

**响应:** 返回更新后的 Agent 对象

### 3.5 删除 Agent

**请求:**

```http
DELETE /api/agents/{agentId}
```

**响应:** HTTP 204（无内容）

**⚠️ 注意:** 有子 Agent 的 Agent 不能删除

### 3.6 获取 Agent 树形结构

**请求:**

```http
GET /api/agents/tree
```

**响应:**

```json
{
  "leader": {
    "id": 1,
    "agentId": "luoshen-leader",
    "name": "洛神总控",
    "type": "LEADER",
    ...
  },
  "coreAgents": [
    {
      "agent": {
        "id": 2,
        "agentId": "device-agent",
        "name": "设备管理Agent",
        "type": "CORE",
        ...
      },
      "subAgents": [
        {
          "id": 3,
          "agentId": "quality-agent",
          "name": "质量检测Agent",
          "type": "SUB",
          ...
        }
      ]
    }
  ]
}
```

### 3.7 按类型获取 Agent

**请求:**

```http
GET /api/agents/type/{type}
```

**参数:**

| 参数 | 位置 | 类型 | 说明 |
|------|------|------|------|
| type | path | string | Agent 类型：LEADER / CORE / SUB |

**响应:** 返回指定类型的 Agent 列表

### 3.8 获取子 Agent

**请求:**

```http
GET /api/agents/{agentId}/children
```

**响应:** 返回指定 Agent 的所有子 Agent 列表

---

## 4. Skill 管理接口

### 4.1 获取所有 Skill

**请求:**

```http
GET /api/skills
```

**响应:**

```json
[
  {
    "id": 1,
    "skillId": "code-review",
    "name": "代码审查",
    "description": "代码质量审查和优化建议",
    "content": "# 代码审查技能\n\n你是代码审查专家...",
    "filePath": null,
    "enabled": true,
    "createdAt": "2026-03-31T10:00:00",
    "updatedAt": "2026-03-31T10:00:00"
  }
]
```

### 4.2 获取单个 Skill

**请求:**

```http
GET /api/skills/{skillId}
```

**响应:** 返回 Skill 对象

### 4.3 创建 Skill

**请求:**

```http
POST /api/skills
Content-Type: application/json

{
  "skillId": "code-review",
  "name": "代码审查",
  "description": "代码质量审查和优化建议",
  "content": "# 代码审查技能\n\n## 角色定义\n你是代码审查专家...\n\n## 审查范围\n1. 代码质量\n2. 安全检查\n3. 性能分析",
  "filePath": null,
  "enabled": true
}
```

**请求体字段:**

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| skillId | string | 是 | 唯一标识 |
| name | string | 是 | 显示名称 |
| description | string | 否 | 功能描述 |
| content | string | 否 | Markdown 格式的技能内容 |
| filePath | string | 否 | 技能文件路径（与 content 二选一）|
| enabled | boolean | 否 | 是否启用，默认 true |

**响应:** 返回创建的 Skill 对象

### 4.4 更新 Skill

**请求:**

```http
PUT /api/skills/{skillId}
Content-Type: application/json

{
  "name": "代码审查（增强版）",
  "content": "# 代码审查技能 v2\n\n..."
}
```

**响应:** 返回更新后的 Skill 对象

### 4.5 删除 Skill

**请求:**

```http
DELETE /api/skills/{skillId}
```

**响应:** HTTP 204（无内容）

---

## 5. MCP 管理接口

### 5.1 获取所有 MCP 配置

**请求:**

```http
GET /api/mcp
```

**响应:**

```json
[
  {
    "id": 1,
    "mcpId": "filesystem-mcp",
    "name": "文件系统",
    "transportType": "STDIO",
    "command": "npx -y @modelcontextprotocol/server-filesystem /data",
    "url": null,
    "argsJson": null,
    "headersJson": null,
    "enabled": true,
    "createdAt": "2026-03-31T10:00:00",
    "updatedAt": "2026-03-31T10:00:00"
  }
]
```

### 5.2 获取单个 MCP 配置

**请求:**

```http
GET /api/mcp/{mcpId}
```

**响应:** 返回 MCP 配置对象

### 5.3 创建 MCP 配置

**请求:**

```http
POST /api/mcp
Content-Type: application/json

{
  "mcpId": "filesystem-mcp",
  "name": "文件系统",
  "transportType": "STDIO",
  "command": "npx -y @modelcontextprotocol/server-filesystem /data",
  "enabled": true
}
```

**请求体字段:**

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| mcpId | string | 是 | 唯一标识 |
| name | string | 是 | 显示名称 |
| transportType | string | 是 | 传输类型：STDIO / SSE / HTTP |
| command | string | 条件 | STDIO 命令（STDIO 类型必填）|
| url | string | 条件 | 服务器 URL（SSE/HTTP 类型必填）|
| argsJson | string | 否 | 命令参数 JSON |
| headersJson | string | 否 | HTTP 头 JSON |
| enabled | boolean | 否 | 是否启用，默认 true |

**响应:** 返回创建的 MCP 配置对象

### 5.4 更新 MCP 配置

**请求:**

```http
PUT /api/mcp/{mcpId}
Content-Type: application/json

{
  "name": "文件系统（更新）",
  "command": "npx -y @modelcontextprotocol/server-filesystem /data/v2"
}
```

**响应:** 返回更新后的 MCP 配置对象

### 5.5 删除 MCP 配置

**请求:**

```http
DELETE /api/mcp/{mcpId}
```

**响应:** HTTP 204（无内容）

---

## 6. 对话接口

### 6.1 同步对话

**请求:**

```http
POST /api/chat/send
Content-Type: application/json

{
  "sessionId": "session-123",
  "agentId": "luoshen-leader",
  "message": "你好，请介绍一下你自己"
}
```

**请求体字段:**

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| sessionId | string | 是 | 会话 ID（同一会话保持上下文）|
| agentId | string | 是 | Agent ID |
| message | string | 是 | 用户消息 |

**响应:**

```json
{
  "sessionId": "session-123",
  "agentId": "luoshen-leader",
  "response": "你好！我是洛神平台的主控智能体..."
}
```

### 6.2 流式对话 (SSE)

**请求:**

```http
POST /api/chat/stream
Content-Type: application/json
Accept: text/event-stream

{
  "sessionId": "session-123",
  "agentId": "luoshen-leader",
  "message": "请写一首诗"
}
```

**响应 (Server-Sent Events):**

```
data: {"type":"CONTENT","content":"春","isLast":false}

data: {"type":"CONTENT","content":"风","isLast":false}

data: {"type":"CONTENT","content":"吹","isLast":false}

data: {"type":"CONTENT","content":"拂","isLast":false}

data: {"type":"CONTENT","content":"...","isLast":true}
```

**响应字段:**

| 字段 | 类型 | 说明 |
|------|------|------|
| type | string | 事件类型：CONTENT / ERROR |
| content | string | 内容片段 |
| isLast | boolean | 是否最后一个片段 |

### 6.3 获取会话历史

**请求:**

```http
GET /api/chat/history/{sessionId}
```

**响应:**

```json
[
  {
    "role": "user",
    "content": "你好，请介绍一下你自己",
    "createdAt": "2026-03-31T10:30:00"
  },
  {
    "role": "assistant",
    "content": "你好！我是洛神平台的主控智能体...",
    "createdAt": "2026-03-31T10:30:05"
  }
]
```

### 6.4 清除会话

**请求:**

```http
DELETE /api/chat/session/{sessionId}
```

**响应:** HTTP 200（成功）

**效果:**
- 清除会话状态（Memory）
- 清除对话历史记录

---

## 7. 仪表盘接口

### 7.1 健康检查

**请求:**

```http
GET /api/dashboard/health
```

**响应:**

```json
{
  "status": "UP",
  "service": "luoshen-admin"
}
```

### 7.2 系统统计

**请求:**

```http
GET /api/dashboard/stats
```

**响应:**

```json
{
  "agentCount": 10,
  "skillCount": 5,
  "mcpCount": 3,
  "sessionCount": 100
}
```

---

## 8. 错误码

### 8.1 业务错误

| 错误码 | 说明 | 解决方案 |
|--------|------|---------|
| AGENT_NOT_FOUND | Agent 不存在 | 检查 agentId 是否正确 |
| AGENT_ID_EXISTS | Agent ID 已存在 | 使用其他 ID |
| AGENT_HAS_CHILDREN | Agent 有子 Agent | 先删除子 Agent |
| AGENT_DISABLED | Agent 已禁用 | 启用 Agent |
| SKILL_NOT_FOUND | Skill 不存在 | 检查 skillId 是否正确 |
| MCP_NOT_FOUND | MCP 不存在 | 检查 mcpId 是否正确 |
| LLM_API_KEY_MISSING | 未配置 LLM API Key | 联系管理员配置 |
| SESSION_NOT_FOUND | 会话不存在 | 检查 sessionId 是否正确 |

### 8.2 参数校验错误

| 错误码 | 说明 |
|--------|------|
| INVALID_AGENT_TYPE | Agent 类型无效（必须是 LEADER/CORE/SUB）|
| MISSING_PARENT_AGENT | CORE/SUB Agent 必须指定父 Agent |
| INVALID_PARENT_TYPE | 父 Agent 类型不匹配 |

---

## 9. 数据模型

### 9.1 AgentConfigEntity

```typescript
interface AgentConfigEntity {
  id: number;                    // 自增主键
  agentId: string;               // 唯一标识
  name: string;                  // 显示名称
  description?: string;          // 功能描述
  type: 'LEADER' | 'CORE' | 'SUB'; // Agent 类型
  parentAgentId?: string;        // 父 Agent ID
  systemPrompt?: string;         // 系统提示词
  modelName?: string;            // LLM 模型名称
  toolsJson?: string;            // 工具列表 JSON
  skillsJson?: string;           // 技能列表 JSON
  mcpServersJson?: string;       // MCP 列表 JSON
  subAgentsJson?: string;        // 子 Agent 列表 JSON
  enabled: boolean;              // 是否启用
  createdAt: string;             // 创建时间
  updatedAt: string;             // 更新时间
}
```

### 9.2 SkillConfigEntity

```typescript
interface SkillConfigEntity {
  id: number;                    // 自增主键
  skillId: string;               // 唯一标识
  name: string;                  // 显示名称
  description?: string;          // 功能描述
  content?: string;              // Markdown 内容
  filePath?: string;             // 文件路径
  enabled: boolean;              // 是否启用
  createdAt: string;             // 创建时间
  updatedAt: string;             // 更新时间
}
```

### 9.3 McpConfigEntity

```typescript
interface McpConfigEntity {
  id: number;                    // 自增主键
  mcpId: string;                 // 唯一标识
  name: string;                  // 显示名称
  transportType: 'STDIO' | 'SSE' | 'HTTP'; // 传输类型
  command?: string;              // STDIO 命令
  url?: string;                  // SSE/HTTP URL
  argsJson?: string;             // 命令参数 JSON
  headersJson?: string;          // HTTP 头 JSON
  enabled: boolean;              // 是否启用
  createdAt: string;             // 创建时间
  updatedAt: string;             // 更新时间
}
```

### 9.4 ChatRequest

```typescript
interface ChatRequest {
  sessionId: string;             // 会话 ID
  agentId: string;               // Agent ID
  message: string;               // 用户消息
}
```

### 9.5 ChatResponse

```typescript
interface ChatResponse {
  sessionId: string;             // 会话 ID
  agentId: string;               // Agent ID
  response: string;              // Agent 回复
}
```

### 9.6 StreamEvent

```typescript
interface StreamEvent {
  type: 'CONTENT' | 'ERROR';     // 事件类型
  content: string;               // 内容片段
  isLast: boolean;               // 是否最后一个片段
}
```

---

## 附录

### A. curl 示例

**创建 Agent:**

```bash
curl -X POST http://localhost:9090/api/agents \
  -H "Content-Type: application/json" \
  -d '{
    "agentId": "test-agent",
    "name": "测试Agent",
    "type": "CORE",
    "parentAgentId": "luoshen-leader",
    "modelName": "qwen-plus",
    "systemPrompt": "你是测试Agent"
  }'
```

**发送对话:**

```bash
curl -X POST http://localhost:9090/api/chat/send \
  -H "Content-Type: application/json" \
  -d '{
    "sessionId": "test-session",
    "agentId": "luoshen-leader",
    "message": "你好"
  }'
```

**流式对话:**

```bash
curl -X POST http://localhost:9090/api/chat/stream \
  -H "Content-Type: application/json" \
  -H "Accept: text/event-stream" \
  -d '{
    "sessionId": "test-session",
    "agentId": "luoshen-leader",
    "message": "请写一首诗"
  }'
```

### B. Postman 导入

可以使用以下 OpenAPI 规范导入 Postman：

```yaml
openapi: 3.0.0
info:
  title: 洛神平台 API
  version: 1.0.0
servers:
  - url: http://localhost:9090
paths:
  /api/agents:
    get:
      summary: 获取所有 Agent
    post:
      summary: 创建 Agent
  # ... 其他接口
```

### C. 版本历史

| 版本 | 日期 | 变更说明 |
|------|------|---------|
| 1.0.0 | 2026-03-31 | 初始版本 |

---

*API 文档维护: 洛神平台开发团队*
