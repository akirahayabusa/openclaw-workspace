<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'

const apiKeys = ref([])
const dialogVisible = ref(false)
const dialogTitle = ref('添加 API Key')
const formData = ref({
  provider: '',
  apiKey: '',
  baseUrl: '',
  defaultModel: '',
  enabled: true
})

const providers = [
  { label: '阿里云灵积 (DashScope)', value: 'dashscope' },
  { label: '火山方舟 (Volcengine)', value: 'volcengine' },
  { label: '智谱 AI (ZhipuAI)', value: 'zhipu' },
  { label: 'OpenAI', value: 'openai' },
  { label: 'Zora', value: 'zora' }
]

// 获取所有 API Key 配置
const fetchApiKeys = async () => {
  try {
    const response = await fetch('http://localhost:9090/api/api-keys')
    const data = await response.json()
    apiKeys.value = data
  } catch (error) {
    ElMessage.error('获取 API Key 配置失败')
  }
}

// 添加 API Key
const handleAdd = () => {
  dialogTitle.value = '添加 API Key'
  formData.value = {
    provider: '',
    apiKey: '',
    baseUrl: '',
    defaultModel: '',
    enabled: true
  }
  dialogVisible.value = true
}

// 编辑 API Key
const handleEdit = (row: any) => {
  dialogTitle.value = '编辑 API Key'
  formData.value = { ...row }
  dialogVisible.value = true
}

// 保存 API Key
const handleSave = async () => {
  try {
    const response = await fetch('http://localhost:9090/api/api-keys', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData.value)
    })
    const result = await response.json()
    
    if (result.success) {
      ElMessage.success('保存成功')
      dialogVisible.value = false
      fetchApiKeys()
    } else {
      ElMessage.error(result.error || '保存失败')
    }
  } catch (error) {
    ElMessage.error('保存失败')
  }
}

// 删除 API Key
const handleDelete = async (row: any) => {
  try {
    await ElMessageBox.confirm('确定要删除此配置吗？', '确认', {
      type: 'warning'
    })
    
    const response = await fetch(`http://localhost:9090/api/api-keys/${row.id}`, {
      method: 'DELETE'
    })
    const result = await response.json()
    
    if (result.success) {
      ElMessage.success('删除成功')
      fetchApiKeys()
    } else {
      ElMessage.error('删除失败')
    }
  } catch (error: any) {
    if (error !== 'cancel') {
      ElMessage.error('删除失败')
    }
  }
}

// 启用/禁用
const handleToggle = async (row: any) => {
  try {
    const response = await fetch(`http://localhost:9090/api/api-keys/${row.id}/toggle`, {
      method: 'PATCH'
    })
    const result = await response.json()
    
    if (result.success) {
      row.enabled = result.enabled
      ElMessage.success(result.enabled ? '已启用' : '已禁用')
    }
  } catch (error) {
    ElMessage.error('操作失败')
  }
}

// 测试 API Key
const handleTest = async (row: any) => {
  try {
    const response = await fetch('http://localhost:9090/api/api-keys/test', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ provider: row.provider, apiKey: row.apiKey })
    })
    const result = await response.json()
    
    if (result.success) {
      ElMessage.success('测试成功')
    } else {
      ElMessage.error(result.error || '测试失败')
    }
  } catch (error) {
    ElMessage.error('测试失败')
  }
}

onMounted(() => {
  fetchApiKeys()
})
</script>

<template>
  <div class="api-key-container">
    <el-card>
      <template #header>
        <div style="display: flex; justify-content: space-between; align-items: center">
          <h2>API Key 管理</h2>
          <el-button type="primary" @click="handleAdd">添加 API Key</el-button>
        </div>
      </template>

      <el-table :data="apiKeys" stripe>
        <el-table-column prop="provider" label="提供商" width="180">
          <template #default="{ row }">
            <el-tag>{{ providers.find(p => p.value === row.provider)?.label || row.provider }}</el-tag>
          </template>
        </el-table-column>
        
        <el-table-column prop="apiKey" label="API Key" show-overflow-tooltip />
        
        <el-table-column prop="baseUrl" label="Base URL" show-overflow-tooltip />
        
        <el-table-column prop="defaultModel" label="默认模型" width="150" />
        
        <el-table-column prop="enabled" label="状态" width="100">
          <template #default="{ row }">
            <el-switch :model-value="row.enabled" @change="handleToggle(row)" />
          </template>
        </el-table-column>
        
        <el-table-column label="操作" width="200">
          <template #default="{ row }">
            <el-button size="small" @click="handleTest(row)">测试</el-button>
            <el-button size="small" type="primary" @click="handleEdit(row)">编辑</el-button>
            <el-button size="small" type="danger" @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-dialog v-model="dialogVisible" :title="dialogTitle" width="500px">
      <el-form :model="formData" label-width="120px">
        <el-form-item label="提供商">
          <el-select v-model="formData.provider" placeholder="请选择提供商" :disabled="dialogTitle === '编辑 API Key'">
            <el-option v-for="p in providers" :key="p.value" :label="p.label" :value="p.value" />
          </el-select>
        </el-form-item>
        
        <el-form-item label="API Key">
          <el-input v-model="formData.apiKey" type="password" show-password placeholder="请输入 API Key" />
        </el-form-item>
        
        <el-form-item label="Base URL">
          <el-input v-model="formData.baseUrl" placeholder="可选，留空使用默认值" />
        </el-form-item>
        
        <el-form-item label="默认模型">
          <el-input v-model="formData.defaultModel" placeholder="可选，留空使用默认值" />
        </el-form-item>
        
        <el-form-item label="启用">
          <el-switch v-model="formData.enabled" />
        </el-form-item>
      </el-form>
      
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSave">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style scoped>
.api-key-container {
  padding: 20px;
}
</style>
