import { createRouter, createWebHistory } from 'vue-router'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/',
      redirect: '/dashboard'
    },
    {
      path: '/dashboard',
      name: 'Dashboard',
      component: () => import('../views/Dashboard.vue')
    },
    {
      path: '/api-keys',
      name: 'ApiKeys',
      component: () => import('../views/ApiKeyManager.vue')
    },
    {
      path: '/agents',
      name: 'Agents',
      component: () => import('../views/AgentList.vue')
    },
    {
      path: '/skills',
      name: 'Skills',
      component: () => import('../views/SkillList.vue')
    },
    {
      path: '/mcp',
      name: 'MCP',
      component: () => import('../views/McpList.vue')
    },
    {
      path: '/chat',
      name: 'Chat',
      component: () => import('../views/ChatView.vue')
    }
  ]
})

export default router
