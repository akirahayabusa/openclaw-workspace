/*
 * Copyright 2024-2026 Luoshen Team
 */
package io.luoshen.admin.controller;

import io.luoshen.admin.model.ApiKeyConfigEntity;
import io.luoshen.admin.repository.ApiKeyConfigRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API Key 管理接口
 */
@RestController
@RequestMapping("/api/api-keys")
@RequiredArgsConstructor
public class ApiKeyController {
    
    private final ApiKeyConfigRepository apiKeyConfigRepository;
    
    /**
     * 获取所有 API Key 配置（隐藏实际密钥）
     */
    @GetMapping
    public ResponseEntity<List<Map<String, Object>>> list() {
        List<ApiKeyConfigEntity> configs = apiKeyConfigRepository.findAll();
        
        // 隐藏 API Key，只显示前4位
        List<Map<String, Object>> result = configs.stream().map(config -> {
            Map<String, Object> map = new HashMap<>();
            map.put("id", config.getId());
            map.put("provider", config.getProvider());
            map.put("apiKey", maskApiKey(config.getApiKey()));
            map.put("baseUrl", config.getBaseUrl());
            map.put("defaultModel", config.getDefaultModel());
            map.put("enabled", config.getEnabled());
            map.put("createdAt", config.getCreatedAt());
            map.put("updatedAt", config.getUpdatedAt());
            return map;
        }).toList();
        
        return ResponseEntity.ok(result);
    }
    
    /**
     * 保存或更新 API Key 配置
     */
    @PostMapping
    public ResponseEntity<Map<String, Object>> save(@RequestBody Map<String, String> request) {
        String provider = request.get("provider");
        String apiKey = request.get("apiKey");
        String baseUrl = request.get("baseUrl");
        String defaultModel = request.get("defaultModel");
        Boolean enabled = Boolean.parseBoolean(request.getOrDefault("enabled", "true"));
        
        if (provider == null || provider.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "error", "提供商不能为空"));
        }
        
        if (apiKey == null || apiKey.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "error", "API Key 不能为空"));
        }
        
        ApiKeyConfigEntity config = apiKeyConfigRepository.findByProvider(provider)
                .orElse(new ApiKeyConfigEntity());
        
        config.setProvider(provider);
        config.setApiKey(apiKey);
        config.setBaseUrl(baseUrl);
        config.setDefaultModel(defaultModel);
        config.setEnabled(enabled);
        
        ApiKeyConfigEntity saved = apiKeyConfigRepository.save(config);
        
        return ResponseEntity.ok(Map.of(
                "success", true,
                "id", saved.getId(),
                "message", "保存成功"
        ));
    }
    
    /**
     * 启用/禁用 API Key
     */
    @PatchMapping("/{id}/toggle")
    public ResponseEntity<Map<String, Object>> toggle(@PathVariable Long id) {
        ApiKeyConfigEntity config = apiKeyConfigRepository.findById(id)
                .orElse(null);
        
        if (config == null) {
            return ResponseEntity.notFound().build();
        }
        
        config.setEnabled(!config.getEnabled());
        apiKeyConfigRepository.save(config);
        
        return ResponseEntity.ok(Map.of(
                "success", true,
                "enabled", config.getEnabled()
        ));
    }
    
    /**
     * 删除 API Key 配置
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, Object>> delete(@PathVariable Long id) {
        if (!apiKeyConfigRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        
        apiKeyConfigRepository.deleteById(id);
        return ResponseEntity.ok(Map.of("success", true, "message", "删除成功"));
    }
    
    /**
     * 测试 API Key 是否有效
     */
    @PostMapping("/test")
    public ResponseEntity<Map<String, Object>> test(@RequestBody Map<String, String> request) {
        String provider = request.get("provider");
        String apiKey = request.get("apiKey");
        
        if (provider == null || apiKey == null) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "error", "参数不完整"));
        }
        
        // TODO: 调用对应提供商的 API 进行测试
        // 这里简单返回成功，实际应该发送测试请求
        
        return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "API Key 测试通过",
                "provider", provider
        ));
    }
    
    /**
     * 遮蔽 API Key（只显示前4位和后4位）
     */
    private String maskApiKey(String apiKey) {
        if (apiKey == null || apiKey.length() <= 8) {
            return "****";
        }
        return apiKey.substring(0, 4) + "****" + apiKey.substring(apiKey.length() - 4);
    }
}
