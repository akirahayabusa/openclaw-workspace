/*
 * Copyright 2024-2026 Luoshen Team
 */
package io.luoshen.admin.repository;

import io.luoshen.admin.model.ApiKeyConfigEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * API Key 配置 Repository
 */
@Repository
public interface ApiKeyConfigRepository extends JpaRepository<ApiKeyConfigEntity, Long> {
    
    /**
     * 根据提供商查找配置
     */
    Optional<ApiKeyConfigEntity> findByProvider(String provider);
}
