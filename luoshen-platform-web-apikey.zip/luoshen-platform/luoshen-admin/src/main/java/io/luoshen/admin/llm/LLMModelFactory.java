/*
 * Copyright 2024-2026 Luoshen Team
 */
package io.luoshen.admin.llm;

import io.agentscope.core.model.DashScopeChatModel;
import io.agentscope.core.formatter.dashscope.DashScopeChatFormatter;
import io.luoshen.admin.repository.ApiKeyConfigRepository;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

/**
 * LLM 模型工厂
 * 支持多个 LLM 提供商
 * 
 * 支持的模型格式：
 * - qwen-plus / qwen-turbo / qwen-max -> 阿里云 DashScope
 * - volcengine:ep-xxx -> 火山方舟
 * - zhipu:glm-4 -> 智谱 AI (ZhipuAI / GLM)
 * - openai:gpt-4 -> OpenAI
 * - zora:model-name -> Zora (OpenAI 兼容接口)
 */
@Slf4j
@Component
public class LLMModelFactory {
    
    private final ApiKeyConfigRepository apiKeyConfigRepository;
    
    public LLMModelFactory(ApiKeyConfigRepository apiKeyConfigRepository) {
        this.apiKeyConfigRepository = apiKeyConfigRepository;
    }
    
    // 环境变量配置（作为默认值）
    @Value("${llm.dashscope.api-key:}")
    private String dashscopeApiKey;
    
    @Value("${llm.dashscope.default-model:qwen-plus}")
    private String dashscopeDefaultModel;
    
    @Value("${llm.dashscope.default-model:qwen-plus}")
    private String dashscopeDefaultModel;
    
    // 火山方舟配置
    @Value("${llm.volcengine.api-key:}")
    private String volcengineApiKey;
    
    @Value("${llm.volcengine.endpoint:https://ark.cn-beijing.volces.com/api/v3}")
    private String volcengineEndpoint;
    
    @Value("${llm.volcengine.default-model:ep-20250321163248-nvl7g}")
    private String volcengineDefaultModel;
    
    // 智谱 AI 配置
    @Value("${llm.zhipu.api-key:}")
    private String zhipuApiKey;
    
    @Value("${llm.zhipu.default-model:glm-4-plus}")
    private String zhipuDefaultModel;
    
    // OpenAI 配置
    @Value("${llm.openai.api-key:}")
    private String openaiApiKey;
    
    @Value("${llm.openai.base-url:https://api.openai.com/v1}")
    private String openaiBaseUrl;
    
    @Value("${llm.openai.default-model:gpt-4o-mini}")
    private String openaiDefaultModel;
    
    // Zora 配置 (OpenAI 兼容)
    @Value("${llm.zora.api-key:}")
    private String zoraApiKey;
    
    @Value("${llm.zora.base-url:https://api.zora.ai/v1}")
    private String zoraBaseUrl;
    
    @Value("${llm.zora.default-model:gpt-4o-mini}")
    private String zoraDefaultModel;
    
    /**
     * 创建 LLM 模型配置
     * 返回一个包含所有必要信息的 Map，供运行时使用
     * 优先从数据库读取配置，如果数据库没有则使用环境变量
     */
    public Map<String, Object> createModelConfig(String modelName) {
        if (modelName == null || modelName.isEmpty()) {
            modelName = dashscopeDefaultModel;
        }
        
        String provider = getProvider(modelName);
        String actualModel = modelName;
        String apiKey = "";
        String endpoint = "";
        
        switch (provider) {
            case "volcengine":
                actualModel = modelName.contains(":") ? modelName.substring(11) : volcengineDefaultModel;
                apiKey = getApiKeyFromDb("volcengine", volcengineApiKey);
                endpoint = getEndpointFromDb("volcengine", volcengineEndpoint);
                log.info("使用火山方舟模型: {}", actualModel);
                break;
                
            case "zhipu":
                actualModel = modelName.contains(":") ? modelName.substring(6) : zhipuDefaultModel;
                apiKey = getApiKeyFromDb("zhipu", zhipuApiKey);
                endpoint = "https://open.bigmodel.cn/api/paas/v4";
                log.info("使用智谱 AI 模型: {}", actualModel);
                break;
                
            case "openai":
                actualModel = modelName.contains(":") ? modelName.substring(7) : openaiDefaultModel;
                apiKey = getApiKeyFromDb("openai", openaiApiKey);
                endpoint = getBaseUrlFromDb("openai", openaiBaseUrl);
                log.info("使用 OpenAI 模型: {}", actualModel);
                break;
                
            case "zora":
                actualModel = modelName.contains(":") ? modelName.substring(5) : zoraDefaultModel;
                apiKey = getApiKeyFromDb("zora", zoraApiKey);
                endpoint = getBaseUrlFromDb("zora", zoraBaseUrl);
                log.info("使用 Zora 模型: {}", actualModel);
                break;
                
            case "dashscope":
            default:
                if (modelName.startsWith("dashscope:")) {
                    actualModel = modelName.substring(11);
                }
                apiKey = getApiKeyFromDb("dashscope", dashscopeApiKey);
                endpoint = "https://dashscope.aliyuncs.com/api/v1";
                log.info("使用 DashScope 模型: {}", actualModel);
                break;
        }
        
        Map<String, Object> config = new HashMap<>();
        config.put("provider", provider);
        config.put("modelName", actualModel);
        config.put("apiKey", apiKey);
        config.put("endpoint", endpoint);
        config.put("stream", true);
        
        return config;
    }
    
    /**
     * 创建 DashScope 模型 (用于 AgentScope 框架)
     */
    public Object createModel(String modelName) {
        Map<String, Object> config = createModelConfig(modelName);
        String provider = (String) config.get("provider");
        
        // AgentScope 目前只原生支持 DashScope
        // 其他提供商通过 HTTP 调用实现
        if ("dashscope".equals(provider)) {
            return DashScopeChatModel.builder()
                    .apiKey((String) config.get("apiKey"))
                    .modelName((String) config.get("modelName"))
                    .stream(true)
                    .formatter(new DashScopeChatFormatter())
                    .build();
        }
        
        // 对于非 DashScope 提供商，返回配置对象
        // ChatService 会通过 HTTP 直接调用
        log.warn("提供商 {} 暂不支持 AgentScope 原生模型，将使用 HTTP 调用", provider);
        return config;
    }
    
    /**
     * 获取提供商类型
     */
    public String getProvider(String modelName) {
        if (modelName == null || modelName.isEmpty()) {
            return "dashscope";
        }
        if (modelName.startsWith("volcengine:")) {
            return "volcengine";
        } else if (modelName.startsWith("zhipu:")) {
            return "zhipu";
        } else if (modelName.startsWith("openai:")) {
            return "openai";
        } else if (modelName.startsWith("zora:")) {
            return "zora";
        } else if (modelName.startsWith("dashscope:")) {
            return "dashscope";
        }
        return "dashscope";
    }
    
    /**
     * 检查是否配置了 API Key
     */
    public boolean hasApiKey(String provider) {
        switch (provider) {
            case "volcengine":
                return volcengineApiKey != null && !volcengineApiKey.isEmpty();
            case "zhipu":
                return zhipuApiKey != null && !zhipuApiKey.isEmpty();
            case "openai":
                return openaiApiKey != null && !openaiApiKey.isEmpty();
            case "zora":
                return zoraApiKey != null && !zoraApiKey.isEmpty();
            default:
                return dashscopeApiKey != null && !dashscopeApiKey.isEmpty();
        }
    }
    
    /**
     * 创建 WebClient (用于非 DashScope 提供商的 HTTP 调用)
     */
    public WebClient createWebClient(String baseUrl) {
        return WebClient.builder()
                .baseUrl(baseUrl)
                .codecs(configurer -> configurer.defaultCodecs().maxInMemorySize(10 * 1024 * 1024))
                .build();
    }
    
    /**
     * 获取请求超时时间
     */
    public Duration getTimeout() {
        return Duration.ofSeconds(300);
    }
    
    /**
     * 从数据库获取 API Key，如果不存在则返回环境变量
     */
    private String getApiKeyFromDb(String provider, String defaultValue) {
        try {
            return apiKeyConfigRepository.findByProvider(provider)
                    .filter(config -> config.getEnabled())
                    .map(config -> {
                        log.debug("从数据库读取 {} 的 API Key", provider);
                        return config.getApiKey();
                    })
                    .orElse(defaultValue);
        } catch (Exception e) {
            log.warn("从数据库读取 API Key 失败，使用环境变量: {}", e.getMessage());
            return defaultValue;
        }
    }
    
    /**
     * 从数据库获取 Base URL
     */
    private String getBaseUrlFromDb(String provider, String defaultValue) {
        try {
            return apiKeyConfigRepository.findByProvider(provider)
                    .filter(config -> config.getEnabled())
                    .map(config -> config.getBaseUrl())
                    .filter(url -> url != null && !url.isEmpty())
                    .orElse(defaultValue);
        } catch (Exception e) {
            return defaultValue;
        }
    }
    
    /**
     * 从数据库获取 Endpoint
     */
    private String getEndpointFromDb(String provider, String defaultValue) {
        return getBaseUrlFromDb(provider, defaultValue);
    }
}
