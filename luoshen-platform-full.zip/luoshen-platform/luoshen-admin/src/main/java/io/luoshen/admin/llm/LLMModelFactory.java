/*
 * Copyright 2024-2026 Luoshen Team
 */
package io.luoshen.admin.llm;

import io.agentscope.core.model.DashScopeChatModel;
import io.agentscope.core.formatter.dashscope.DashScopeChatFormatter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * LLM 模型工厂
 * 根据模型名称前缀选择对应的提供商
 * 
 * 支持的模型格式：
 * - qwen-plus / qwen-turbo / qwen-max -> DashScope
 * - volcengine:/ep-xxx -> 火山方舟
 * - openai:/gpt-4 -> OpenAI
 */
@Slf4j
@Component
public class LLMModelFactory {
    
    // DashScope 配置
    @Value("${llm.dashscope.api-key:}")
    private String dashscopeApiKey;
    
    @Value("${llm.dashscope.default-model:qwen-plus}")
    private String dashscopeDefaultModel;
    
    // 火山方舟配置
    @Value("${llm.volcengine.api-key:}")
    private String volcengineApiKey;
    
    @Value("${llm.volcengine.default-model:}")
    private String volcengineDefaultModel;
    
    // OpenAI 兼容配置
    @Value("${llm.openai.api-key:}")
    private String openaiApiKey;
    
    @Value("${llm.openai.base-url:https://api.openai.com/v1}")
    private String openaiBaseUrl;
    
    @Value("${llm.openai.default-model:gpt-4o-mini}")
    private String openaiDefaultModel;
    
    /**
     * 创建 DashScope 模型
     * 目前只支持 DashScope，火山方舟和 OpenAI 需要后续扩展
     */
    public Object createModel(String modelName) {
        if (modelName == null || modelName.isEmpty()) {
            modelName = dashscopeDefaultModel;
        }
        
        // 解析前缀
        String actualModel = modelName;
        String apiKey = dashscopeApiKey;
        
        if (modelName.startsWith("volcengine:")) {
            actualModel = modelName.substring(11);
            apiKey = volcengineApiKey;
            log.info("使用火山方舟模型: {}", actualModel);
        } else if (modelName.startsWith("openai:")) {
            actualModel = modelName.substring(7);
            apiKey = openaiApiKey;
            log.info("使用 OpenAI 模型: {}", actualModel);
        } else {
            log.info("使用 DashScope 模型: {}", actualModel);
        }
        
        // 目前统一使用 DashScopeChatModel
        // TODO: 后续需要添加火山方舟和 OpenAI 的支持
        return DashScopeChatModel.builder()
                .apiKey(apiKey)
                .modelName(actualModel)
                .stream(true)
                .formatter(new DashScopeChatFormatter())
                .build();
    }
    
    /**
     * 获取提供商类型
     */
    public String getProvider(String modelName) {
        if (modelName == null) {
            return "dashscope";
        }
        if (modelName.startsWith("volcengine:")) {
            return "volcengine";
        } else if (modelName.startsWith("openai:")) {
            return "openai";
        }
        return "dashscope";
    }
    
    /**
     * 检查是否配置了 API Key
     */
    public boolean hasApiKey(String provider) {
        switch (provider) {
            case "volcengine":
                return volcengineApiKey != null && !volcengineApiKey.isEmpty();
            case "openai":
                return openaiApiKey != null && !openaiApiKey.isEmpty();
            default:
                return dashscopeApiKey != null && !dashscopeApiKey.isEmpty();
        }
    }
}
